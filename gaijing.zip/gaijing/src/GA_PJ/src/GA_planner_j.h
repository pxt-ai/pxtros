#ifndef GA_PLANNER_J_H
#define GA_PLANNER_J_H
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 
#include <string>

/** include the libraries you need in your planner here */
#include <ros/ros.h>

#include <actionlib/client/simple_action_client.h>
#include <move_base_msgs/MoveBaseAction.h>

#include <geometry_msgs/Twist.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <move_base_msgs/MoveBaseGoal.h>
#include <move_base_msgs/MoveBaseActionGoal.h>

#include "sensor_msgs/LaserScan.h"
#include "sensor_msgs/PointCloud2.h"

#include <nav_msgs/Odometry.h>
#include <nav_msgs/OccupancyGrid.h>
#include <nav_msgs/Path.h>
#include <nav_msgs/GetPlan.h>

#include <tf/tf.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_listener.h>

#include <boost/foreach.hpp>
//#define forEach BOOST_FOREACH

/** for global path planner interface */
#include <costmap_2d/costmap_2d_ros.h>
#include <costmap_2d/costmap_2d.h>
#include <nav_core/base_global_planner.h>

#include <geometry_msgs/PoseStamped.h>
#include <angles/angles.h>

//#include <pcl_conversions/pcl_conversions.h>
#include <base_local_planner/world_model.h>
#include <base_local_planner/costmap_model.h>
#include<algorithm>
#include<vector>
#include<iostream>
#include <set>
struct cells {
	int currentCell;
	float fCost;

};      
namespace GA_planne_j
{


class GA_P:public nav_core::BaseGlobalPlanner
{

	public:
		GA_P();
		
		~GA_P()
		{

		}
		
        GA_P(ros::NodeHandle &);
        GA_P(std::string name, costmap_2d::Costmap2DROS* costmap_ros);
		float p_select;
		float p_crs;
		float p_mut;
		int N;
		int M;
		float globfit;
		int pointNum;
		float alpha;
		int inters = 0;
        bool iinit;
        int width,height;
         ros::NodeHandle ROSNodeHandle;
         ros::Publisher _plan_pub;
         std::string _frame_id;
         float originX;
         float originY;
     float resolution;
       costmap_2d::Costmap2DROS* costmap_ros_;
            //double step_size_, min_dist_from_robot_;
    costmap_2d::Costmap2D* costmap_;
   
		float start_x, start_y, end_x, end_y;
		std::vector<std::vector<int>> map;
		std::vector<int> select_indx;
		struct v {
			std::vector<float> x;
			std::vector<float> y;
		};
		struct pos
		{
			std::vector<float> x;
			std::vector<float> y;
		};
		struct glob {
			std::vector<std::vector<float>>path;
			float fintess;
			pos poss;
		};
		struct Best
		{
			pos pos2;
			float fitness;
			std::vector<std::vector<float>> path;

		};

		struct particles
		{
			pos pos1;
			v v1;
			int flag = 0;
			float fitness;
			std::vector<std::vector<float>> path;
			Best best;

		};
		particles partic;
		std::vector<particles>par;
		glob glaob;
		int index = 0;
		void posinit();
		void calFitness();
		void init(float s_x, float s_y, float e_x, float e_y);
		void select();
		void cross_connection();
		void variation();
         void getCorrdinate (float& x, float& y); 
		 
	 void initialize(std::string name, costmap_2d::Costmap2DROS* costmap_ros);

	// void getCorrdinate (float& x, float& y);
  int convertToCellIndex (float x, float y);
  void convertToCoordinate(int index, float& x, float& y);
  bool isCellInsideMap(float x, float y);
  void mapToWorld(double mx, double my, double& wx, double& wy);
 std::vector<int> BAstarPlanner(int startCell, int goalCell);
  std::vector<int> findPath(int startCell, int goalCell, float g_score[]);
  std::vector<int> constructPath(int startCell, int goalCell, float g_score[]);
  float calculateHCost(int cellID, int goalCell);
  void addNeighborCellToOpenList(std::multiset<cells> & OPL, int neighborCell, int goalCell, float g_score[]);
  std::vector <int> findFreeNeighborCell (int CellID);
  bool isStartAndGoalCellsValid(int startCell,int goalCell); 
  float getMoveCost(int CellID1, int CellID2);
  float getMoveCost(int i1, int j1, int i2, int j2);
  bool isFree(int CellID); //returns true if the cell is Free
  bool isFree(int i, int j); 
int ind_c=0;
  int getCellIndex(int i,int j) //get the index of the cell to be used in Path
  {
   return (i*width)+j;  
  }
  int getCellRowID(int index)//get the row ID from cell index
  {
     return index/width;
  }
  int getCellColID(int index)//get colunm ID from cell index
  {
    return index%width;
  }
  float BSplineBasis(int i, int k, float t, const std::vector<float>& knots);
std::pair<float, float> CubicBSplinePoint(float t, const std::vector<std::pair<float, float>>& controlPoints, const std::vector<float>& knots) ;
std::vector<std::pair<float, float>> GenerateSmoothPoints(const std::vector<std::pair<float, float>>& controlPoints, int numPoints);

    bool makePlan(const geometry_msgs::PoseStamped& start, const geometry_msgs::PoseStamped& goal,  std::vector<geometry_msgs::PoseStamped>& plan );
};

};
#endif