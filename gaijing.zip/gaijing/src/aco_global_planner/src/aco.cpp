#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <string>
#include <cmath>
#include <time.h>
#include <random>
#include <vector>
#include "aco.h"
#include<algorithm>

#include <pluginlib/class_list_macros.h>

using namespace std;

PLUGINLIB_EXPORT_CLASS(ACO_planner::AcoPlannerROS, nav_core::BaseGlobalPlanner)
  //  vector<int>yizou;
int mapSize; 
bool *OGM;
vector<vector<float>> pheromoneMatrix;  //信息素矩阵
random_device rd;
static default_random_engine generator ( rd() );

ofstream MyExcelFile("ACO_result.xlsx", ios::trunc);

int clock_gettime(clockid_t clk_id, struct timespect *tp);

timespec diff(timespec start, timespec end)
{
  timespec temp;
  if ((end.tv_nsec - start.tv_nsec) < 0)
  {
    temp.tv_sec = end.tv_sec - start.tv_sec - 1;
    temp.tv_nsec = 1000000000 + end.tv_nsec - start.tv_nsec;
  }
  else
  {
    temp.tv_sec = end.tv_sec - start.tv_sec;
    temp.tv_nsec = end.tv_nsec - start.tv_nsec;
  }
  return temp;
}


namespace ACO_planner
{   
    AcoPlannerROS::AcoPlannerROS(){}
    AcoPlannerROS::AcoPlannerROS(ros::NodeHandle &nh)
    {
        ROSNodeHandle = nh;
    }
    AcoPlannerROS::AcoPlannerROS(std::string name, costmap_2d::Costmap2DROS *costmap_ros)
    {
        initialize(name, costmap_ros);
    }

    void AcoPlannerROS::initialize(std::string name, costmap_2d::Costmap2DROS *costmap_ros)
    {
        initialized_ = false;
        if (!initialized_)
        {
             
            costmap_ros_ = costmap_ros;
            costmap_ = costmap_ros_->getCostmap();

            ros::NodeHandle private_nh("~/" + name);
            _plan_pub = private_nh.advertise<nav_msgs::Path>("global_plan", 1);
            _frame_id = costmap_ros->getGlobalFrameID();

            originX = costmap_->getOriginX();
            originY = costmap_->getOriginY();

            width = costmap_->getSizeInCellsX();
            height = costmap_->getSizeInCellsY();
            resolution = costmap_->getResolution();
            mapSize = width * height;
 
            private_nh.param("initialPheromoneValue_",initialPheromoneValue,float(8.0));  //初始化信息素
            private_nh.param("Alpha_",Alpha,1);
            private_nh.param("Beta_",Beta,7);
            private_nh.param("EvaporationRate_",EvaporationRate,float(0.5));
            private_nh.param("NumberOfAnts_",NumberOfAnts,30);               //初始化蚂蚁数量
            private_nh.param("NumberOfIterations_",NumberOfIterations,20);  //初始化迭代次数
           
           OGM = new bool[mapSize];

            for (unsigned int iy = 0; iy < costmap_->getSizeInCellsY(); iy++)
            {
                for (unsigned int ix = 0; ix < costmap_->getSizeInCellsX(); ix++)
                {
                    unsigned int cost = static_cast<int>(costmap_->getCost(ix, iy));
                    if (cost == 0)
                        {OGM[iy* width + ix] = true;}
                    else
                     {   OGM[iy * width + ix] = false;}
                }
            }
          //  ROS_INFO("1");
            //if(width>height)

          // { 
           //    for (int i = 0; i <width ; i++)
	       // {
		   //     pheromoneMatrix.push_back(vector<float>());//不断往v2d里加行 
	      //  }
        //   }
         //  else
         //  {
           
             //  ROS_INFO("2");
            MyExcelFile << "StartID\tStartX\tStartY\tGoalID\tGoalX\tGoalY\tPlannertime(ms)\tpathLength\tnumberOfCells\t" << endl;
            ROS_INFO("ACO planner initialized successfully");
            initialized_ = true;
        }
        else
        {
            ROS_WARN("This planner has already been initialized... doing nothing");

        }   
       

    }

    
    bool AcoPlannerROS::makePlan(const geometry_msgs::PoseStamped &start, const geometry_msgs::PoseStamped &goal,std::vector<geometry_msgs::PoseStamped> &plan)
    {
        if (!initialized_)
        {
            ROS_ERROR("The planner has not been initialized, please call initialize() to use the planner");
            return false;
        } 
  pheromoneMatrix.clear();
        ROS_DEBUG("Got a start: %.2f, %.2f, and a goal: %.2f, %.2f", start.pose.position.x, start.pose.position.y,goal.pose.position.x, goal.pose.position.y);
    ROS_INFO("0");
        plan.clear();    
		        
             for (int i = 0; i <height ; i++)
	        {
		        pheromoneMatrix.push_back(vector<float>());//不断往v2d里加行 
	        }
           //}
	        for (int i = 0; i <height; i++)//行 
	        {
		        for (int j = 0; j < width; j++)//添加5列 
		         
		        {
			        pheromoneMatrix[i].push_back(initialPheromoneValue);
            
		        }
	        }         
    
        if (goal.header.frame_id != costmap_ros_->getGlobalFrameID())
        {
            ROS_ERROR("This planner as configured will only accept goals in the %s frame, but a goal was sent in the %s frame.",
                costmap_ros_->getGlobalFrameID().c_str(), goal.header.frame_id.c_str());
            return false;
        }  
        vector<geometry_msgs::PoseStamped>xuelinlin;
        tf::Stamped<tf::Pose> goal_tf;
        tf::Stamped<tf::Pose> start_tf;

        poseStampedMsgToTF(goal, goal_tf);
        poseStampedMsgToTF(start, start_tf);

        float startX = start.pose.position.x;
        float startY = start.pose.position.y;
//ROS_INFO("stary=%.2f",startY);
        float goalX = goal.pose.position.x;
        float goalY = goal.pose.position.y;
        //ROS_INFO("goaly=%.2f",goalY);

        getCorrdinate(startX, startY);   //获取起点在世界坐标系下的坐标
        getCorrdinate(goalX, goalY);     

        int startCell;
        int goalCell;
        // ROS_INFO("goaly=%d",goalCell);

        if (isCellInsideMap(startX, startY) && isCellInsideMap(goalX, goalY))
        {
            startCell = convertToCellIndex(startX, startY);   //获取起点坐标的栅格索引值
          //  ROS_INFO("startcell=:%d",startCell);

  //ROS_INFO("startcell=:%.2f",goalY);
            goalCell = convertToCellIndex(goalX, goalY);      //获取终点坐标的栅格索引值
           //  ROS_INFO("goalcell=:%d",goalCell);


            MyExcelFile << startCell << "\t" << start.pose.position.x << "\t" << start.pose.position.y << "\t" << goalCell << "\t" << goal.pose.position.x << "\t" << goal.pose.position.y;
        }
        else
        {
            ROS_WARN("the start or goal is out of the map");
            return false;
        }  
       // ROS_INFO("4");

        //进行全局规划
        if (isStartAndGoalCellsValid(startCell, goalCell))
        { 
            //ROS_INFO("startcell1=:%d",startCell);
            vector<int> bestPath;   //记录最佳路径索引值
            bestPath.clear();
            bestPath = acoPlanner(startCell, goalCell);
            //  ROS_INFO("5");
            if (bestPath.size() > 0)
            {
                for (int i = 0; i < bestPath.size(); i++)
                {

                    float x = 0.0;
                    float y = 0.0;

                    int index = bestPath[i];

                    convertToCoordinate(index, x, y);

                    geometry_msgs::PoseStamped pose = goal;

                    pose.pose.position.x = x;
                    pose.pose.position.y = y;
                    pose.pose.position.z = 0.0;

                    pose.pose.orientation.x = 0.0;
                    pose.pose.orientation.y = 0.0;
                    pose.pose.orientation.z = 0.0;
                    pose.pose.orientation.w = 1.0;

                    plan.push_back(pose);
                }

                float path_length = 0.0;
                std::vector<geometry_msgs::PoseStamped>::iterator it = plan.begin();    
                geometry_msgs::PoseStamped last_pose;
                last_pose = *it;
                it++;
               // ROS_INFO("6");
                for (; it != plan.end(); ++it)
                {
                    path_length += hypot((*it).pose.position.x - last_pose.pose.position.x,
                                        (*it).pose.position.y - last_pose.pose.position.y);
                    last_pose = *it;
                }           
                cout << "The global path length: " << path_length << " meters" << endl;
                MyExcelFile << "\t" << path_length << "\t" << plan.size() << endl;
                //publish the plan
                nav_msgs::Path path;
                path.poses.resize(plan.size());  
                if (plan.empty())
                {
                    //still set a valid frame so visualization won't hit transform issues
                    path.header.frame_id = _frame_id;
                    path.header.stamp = ros::Time::now();
                }
                else
                {
                    path.header.frame_id = plan[0].header.frame_id;
                    path.header.stamp = plan[0].header.stamp;
                }           

                // Extract the plan in world co-ordinates, we assume the path is all in the same frame
                for (int i = 0; i < plan.size(); i++)
                {
                    path.poses[i] = plan[i];
                }
//ROS_INFO("7");
                _plan_pub.publish(path);
               
                return true;
            }
            else
            {
                ROS_WARN("The planner failed to find a path, choose other goal position");
               
                return false;
            }
        }

        else
        {
            ROS_WARN("Not valid start or goal");
             pheromoneMatrix.clear();
            return false;
        }
         
          
    }
    
    void AcoPlannerROS::getCorrdinate(float &x, float &y)
    {//ROS_INFO("8");
        x = x - originX;
        y = y - originY;
    }

    int AcoPlannerROS::convertToCellIndex(float x, float y)
    {
//ROS_INFO("9");
        int cellIndex;

        float newX = x / resolution;  //求栅格横坐标
        float newY = y / resolution;  //求栅格纵坐标

        cellIndex = getCellIndex(newY, newX);  //获得索引值
//ROS_INFO("9=%d",cellIndex);
        return cellIndex;
    }

   
    void AcoPlannerROS::convertToCoordinate(int index, float &x, float &y)  //转换到世界坐标系下
    {
//ROS_INFO("10");
        x = getCellColID(index) * resolution;

        y = getCellRowID(index) * resolution;

        x = x + originX;
        y = y + originY;
     //   ROS_INFO("x=:%.2f",x );
    }
    bool AcoPlannerROS::isCellInsideMap(float x, float y)
    {//ROS_INFO("11");
        bool valid = true;

        if (x > (width * resolution) || y > (height * resolution) )
           {valid = false;}

        return valid;
    }
    void AcoPlannerROS::mapToWorld(double mx,double my,double &wx,double &wy)
    {
        costmap_2d::Costmap2D *costmap=costmap_ros_->getCostmap();
        wx=costmap->getOriginX()+mx*resolution;
        wy=costmap->getOriginY()+my*resolution;

    }


    vector<int> AcoPlannerROS::acoPlanner(int startCell, int goalCell)
    {//ROS_INFO("13");
    //ROS_INFO("startcell2=:%d",startCell);
        vector<int> bestPath;       
        timespec time1, time2;
        /* take current time here */
        clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &time1);
        bestPath = findPath(startCell, goalCell);   
        clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &time2);      
        cout << "time to generate best global path by the new planner ACO = " << (diff(time1, time2).tv_sec) * 1e3 + (diff(time1, time2).tv_nsec) * 1e-6 << " microseconds" << endl;
        MyExcelFile << "\t" << (diff(time1, time2).tv_sec) * 1e3 + (diff(time1, time2).tv_nsec) * 1e-6;   
        return bestPath;  
    }

    vector<int> AcoPlannerROS::findPath(int startCell, int goalCell)
    {  // ROS_INFO("14");
  //  ROS_INFO("startcell3=:%d",startCell);
        vector<int> bestPath;    //记录最佳路径
        bestPath.clear();
        int nextCell;
        float best_path_length = 1000000.0;
        for(int i = 0; i < NumberOfIterations; i++)  //迭代多少次
        {
            vector<int> path;                        //记录一条路径
            vector<int> neighbors;                   //获取周边邻居的栅格索引
            vector<float> probabilities;             //存储状态转移概率
            //vector<int> unvisitedFreeNeighborCell;    //获取未被访问过的自由栅格索引
           for(int j = 0; j < NumberOfAnts; j++)    //每次迭代有多少只蚂蚁
           {
               path.clear();
               neighbors.clear();
               probabilities.clear();
               int index = 0;                           //一只蚂蚁当前的寻路次数
               int currentCell = startCell;
                 //ROS_INFO("startcell3=:%d",currentCell);
               path.push_back(currentCell);
               float path_length = 0.0;
              // int k=0;
               while(currentCell!=goalCell)  //判断是否到达目标点
               {                  
                    neighbors = getneighbors(currentCell,path);  //获取周围没有走过的且是自由的栅格
                   //ROS_INFO("i=%d",startCell);
                  //  k++;
                    //ROS_INFO("shi duo %d  ",neighbors.size());
                    if(neighbors.empty())  //判断是否周围没有空用的栅格
                    {
                       // ROS_INFO("66");
                        path.clear();           //删除路径上的点
                        neighbors.clear();      //删除邻居栅格
                        break;
                    }
                    else
                    {

                                                                                                                   //ROS_INFO("shi duo %d  ",neighbors.size());
                        //计算周围可行走栅格的转移概率，获取下一个栅格的位置
		                probabilities = computeTransitionProbabilities(goalCell, neighbors, currentCell);  //计算转移概率
                         //    ROS_INFO("50");
                        nextCell = getNextCell(neighbors, probabilities);          //通过轮盘赌的方式计算下一个可行走的栅格
                       // ROS_INFO("nex1%d",nextCell);
                            // ROS_INFO("51");
                        neighbors.clear();  
                        probabilities.clear();   //清空概率
                       // ROS_INFO("45");
                        //currentCell = nextCell;
                    }
                    currentCell = nextCell;
                    neighbors = getneighbors(currentCell,path);
                    //ROS_INFO("nex2%d",nextCell);
                    
                    index++;
                    path.push_back(currentCell);  //将当前栅格放入路径中
                   // ROS_INFO("size%d",path.size());

                    if(currentCell == goalCell)   //判断当前的栅格是否是目标栅格
                    {
                        int CellID1;
                        int CellID2;
                        float step;
                        for(int k = 0; k < path.size()-1; k++)
                        {
                            CellID1 = path[k];
                            CellID2 = path[k+1];
                            step = getMoveCost(CellID1,CellID2);
                            path_length = path_length + step;
                        }
                        if (path_length < best_path_length)
                        {
                            best_path_length = path_length;
                            bestPath.clear();
                            bestPath = path;  //把当前路径放到最佳路径中
                        }
                    }
               }
               //更新全局信息素
               for(int i = 0 ; i < height;i++)
               {
                   for(int j = 0; j < width; j++)
                   {
                     //  ROS_INFO("99");
                        pheromoneMatrix[i][j] =0.8*  pheromoneMatrix[i][j];                      
                   }
               }

               for(int k = 0; k < path.size(); k++)
               {
                   pheromoneMatrix[path[k]/width][path[k]%width] = pheromoneMatrix[path[k]/width][path[k]%width] + (50 / path_length);
               }
               path.clear();   //清空路径的栅格索引信息
           }
        }
        //ROS_INFO("bestsize%d",bestPath.size());
         return bestPath;
    }

    bool AcoPlannerROS::isStartAndGoalCellsValid(int startCell, int goalCell)
    {//ROS_INFO("15");
        bool isvalid = true;
        bool isFreeStartCell = isFree(startCell);
        bool isFreeGoalCell = isFree(goalCell);
    
        if (startCell == goalCell)   
        {
            //cout << "The Start and the Goal cells are the same..." << endl;
            isvalid = false;
        }
        else
        {
            if (!isFreeStartCell && !isFreeGoalCell)   
            {
                //cout << "The start and the goal cells are obstacle positions..." << endl;
                isvalid = false;
            }
            else
            {
                if (!isFreeStartCell)
                {
                    //cout << "The start is an obstacle..." << endl;
                    isvalid = false;
                }
                else
                {
                    if (!isFreeGoalCell)
                    {
                        //cout << "The goal cell is an obstacle..." << endl;
                        isvalid = false;
                    }
                    else
                    {
                        if (findFreeNeighborCell(goalCell).size() == 0)
                        {
                            //cout << "The goal cell is encountred by obstacles... "<< endl;
                            isvalid = false;
                        }
                        else
                        {
                            if (findFreeNeighborCell(startCell).size() == 0)
                            {
                                //cout << "The start cell is encountred by obstacles... "<< endl;
                                isvalid = false;
                            }
                        }
                    }
                }
            }
        }
        return isvalid;
    }

    vector<int> AcoPlannerROS::findFreeNeighborCell(int CellID) //判断栅格在地图内部
    {//ROS_INFO("16");
        int rowID = getCellRowID(CellID);//y
        int colID = getCellColID(CellID);//x
        int neighborIndex;
        vector<int> freeNeighborCells;

        for (int i = -1; i <= 1; i++)
        {
            for (int j = -1; j <= 1; j++)
            {
                //check whether the index is valid
                if ((rowID + i >= 0) && (rowID + i < height) && (colID + j >= 0) && (colID + j < width) && (!(i == 0 && j == 0)))
                {
                    neighborIndex = getCellIndex(rowID + i, colID + j);
                    if (isFree(neighborIndex))
                        freeNeighborCells.push_back(neighborIndex);
                }
            }
        }
        return freeNeighborCells;
  }

  bool AcoPlannerROS::isVisited(int nextIndex, vector<int> path)  //判断当前栅格是否已经在走过的路径上
  {
      //ROS_INFO("17");
	for (int i = 0; i < path.size(); i++)
	{
		if (nextIndex == path[i])
			return true;
	}
	return false;
  }

bool AcoPlannerROS::IsInBounds(int nextX, int nextY)
{
   // ROS_INFO("18");
    if (nextX < 0 || nextX > width || nextY < 0 || nextY > height)
    {
        return false;
    }
    return true;
}

  vector<int> AcoPlannerROS::getneighbors(int currentCell, vector<int> path)
  {//ROS_INFO("19");
        vector<int> neighborIndexes;
        neighborIndexes.clear();
     //   vector<int>yiyou;
        
        for (int i = -1; i <= 1; i++)
        {
            for (int j = -1; j <= 1; j++)
            {
         int tmp1 = getCellColID(currentCell);  //获得栅格坐标系下的x
         int tmp2 = getCellRowID(currentCell);  //获得栅格坐标系下的y
       
                //ROS_INFO("temp1=%d temp2=%d",tmp1,tmp2);
                if(i==0&&j==0)
                {
                    continue;
                }
               
                int nextX = tmp1 + i;   
                int nextY = tmp2 + j;
              //  ROS_INFO("nextx=%d nexty=%d",nextX,nextY);
                 //ROS_INFO("nx=%d ny=%d",nextX,nextY);
                if (nextX < 0 || nextX > width || nextY < 0 || nextY > height)   //这里已经判断了一个栅格是否越界
                {
                    //ROS_INFO("27");
                    continue;
                }
                int nextIndex = getCellIndex(nextY, nextX);  //获得栅格索引值
                
             //  ROS_INFO("nextindex%d",nextIndex);
                if(!( i == 0 && j == 0) && OGM[nextIndex] && !isVisited(nextIndex, path))
                {//ROS_INFO("33");
                    neighborIndexes.push_back(nextIndex);
                }
            }
        }
         //ROS_INFO("n=%d",neighborIndexes.size());
        return neighborIndexes;
  }

    vector<float> AcoPlannerROS::computeTransitionProbabilities(int goalCell, vector<int> neighbors, int currentCell)
    {//ROS_INFO("20");
        vector<float> temp_probabilities;  
        

        //暂时存储转移概率
      //  vector<int>neighbors;
       // neighbors=neighbors1;
        float etha;                        //距离启发值
         int temp1,temp2;
        int temp3,temp4;
        //convertToCoordinate(goalCell, temp1, temp2);   //转换终点坐标(世界坐标系下)
       // ROS_INFO("size=%d",neighbors.size());
       temp1=getCellColID(goalCell);
       temp2=getCellRowID(goalCell);
       

        for(int i = 0; i < neighbors.size();i++)
        {
            //convertToCoordinate(neighbors[i], temp3, temp4);   //转换到世界坐标系下
            temp3=getCellColID(neighbors[i]);
            temp4=getCellRowID(neighbors[i]);
            //ROS_INFO("int %d",neighbors[i]);
            float distance_x = fabs(temp1-temp3);
            float distance_y = fabs(temp2-temp4);
            //ROS_INFO("diatx=%.2f",distance_x);
            //ROS_INFO("35");
            if (distance_x == 0.0 && distance_y == 0.0)   //周围的栅格中存在一个栅格是目标栅格
            {
                distance_x =0.0001;
                 distance_y=0.0001;

              
            }
          
             //ROS_INFO("36");
            etha = abs((float) 1 / (distance_x + distance_y));
               //ROS_INFO("etha=%.2f",etha);
              // int c1=getCellColID()
            temp_probabilities.push_back((float)pow(pheromoneMatrix[int(neighbors[i]/width)][int(neighbors[i]%width)],Alpha) * (float)pow(etha,Beta)); 
          //  if((float)pow(pheromoneMatrix[neighbors[i]/width][neighbors[i]/height],Alpha) * (float)pow(etha,Beta)<0.1)
        //    {temp_probabilities.push_back(0.2);}
           //  ROS_INFO("37=%.2f",pheromoneMatrix[neighbors[i]/width][neighbors[i]/height]);
        }
       
        float sum = 0.0;
        for(int j = 0; j < neighbors.size(); j++)
        {
            sum = sum + temp_probabilities[j];

        }
        //ROS_INFO("sum %.2f",sum);
        if(sum > 0.0)
        {
            for(int i = 0; i < neighbors.size(); i++)
            {
                   temp_probabilities[i] =  temp_probabilities[i] / sum;       
                 //  ROS_INFO("temp _p%.2f",temp_probabilities[i] ) ;
            }
        }
        
        
        
        return temp_probabilities;
    }

    bool AcoPlannerROS::isFree(int CellID)  //判断栅格是否是障碍物
    {//ROS_INFO("21");
        return OGM[CellID];
    }
 int AcoPlannerROS::getNextCell(vector<int> neighbors, vector<float> probabilities)  //选取下一个移动的栅格
    {
        int NextCell;
        vector<float> cumulativeProbabilities;
        float randomNumber;
            //cumulativeProbabilities.push_back(probabilities[0]);

            for ( int i = 0; i < probabilities.size(); i++)   //为轮盘赌做准备
            {
                    cumulativeProbabilities.push_back( probabilities[i]);
            }

int pos=int(max_element(cumulativeProbabilities.begin(),cumulativeProbabilities.end())-cumulativeProbabilities.begin());
        srand(time(0));
        randomNumber = 1 - ((float)rand() / (float)RAND_MAX);  //随机生成一个随机数

        for(int j = 0; j < neighbors.size();j++)
        {
            if (randomNumber <= cumulativeProbabilities[j])
            {
                NextCell = neighbors[pos];
            }

            if (randomNumber > cumulativeProbabilities.back())
            {
                NextCell = neighbors[pos];
            }
        }
        return NextCell;
    }

  
    float AcoPlannerROS::getMoveCost(int CellID1, int CellID2)
    {//ROS_INFO("23");
        int i1 = 0, i2 = 0, j1 = 0, j2 = 0;

        i1 = getCellRowID(CellID1);
        j1 = getCellColID(CellID1);
        i2 = getCellRowID(CellID2);
        j2 = getCellColID(CellID2);

        return getMoveCost(i1, j1, i2, j2);
    }

    float AcoPlannerROS::getMoveCost(int i1, int j1, int i2, int j2)
    {//ROS_INFO("24");
        float moveCost = 100.0; //start cost with maximum value. Change it to real cost of cells are connected
        //if cell2(i2,j2) exists in the diagonal of cell1(i1,j1)
        if ((j2 == j1 + 1 && i2 == i1 + 1) || (i2 == i1 - 1 && j2 == j1 + 1) || (i2 == i1 - 1 && j2 == j1 - 1) || (j2 == j1 - 1 && i2 == i1 + 1))
        {
            //moveCost = DIAGONAL_MOVE_COST;
             moveCost = 1.4;
        }
            //if cell 2(i2,j2) exists in the horizontal or vertical line with cell1(i1,j1)
        else
        {
            if ((j2 == j1 && i2 == i1 - 1) || (i2 == i1 && j2 == j1 - 1) || (i2 == i1 + 1 && j2 == j1) || (i1 == i2 && j2 == j1 + 1))
            {
                //moveCost = MOVE_COST;
                moveCost = 1.0;
            }
        }
            return moveCost;
    }

};
