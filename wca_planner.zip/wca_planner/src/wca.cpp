#include"wca.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <string>
#include <cmath>
#include <time.h>
#include <random>
#include <vector>
#include <math.h>
#include<algorithm>
#include <numeric>

#include <pluginlib/class_list_macros.h>
PLUGINLIB_EXPORT_CLASS(WCA_Planner::wca, nav_core::BaseGlobalPlanner)
namespace WCA_Planner
{
    wca::wca()
    {

    }
    wca::wca(ros::NodeHandle &nh)
    {
        ROSNodeHandle = nh;
    }
     wca::wca(std::string name, costmap_2d::Costmap2DROS* costmap_ros)
     {
            initialize(name,  costmap_ros);
     }
      void wca::initialize(std::string name, costmap_2d::Costmap2DROS* costmap_ros)
      {
            std::vector<int>ma;
            int cost;
            glaob.fintess = 10000000.0;
            M = 100;
	       pointNum =5;
	       N = 50;
	       alpha = 0.5;
	      S_num = M * alpha;
	      M_num = M - S_num;
	      S = 20.0;
	      mapRange=500.0;
	      step_a = mapRange / S;
          step_b = 2 * step_a;
	      step_c = step_a / 2;
	    	h = 20;
	       d0 = 1000;
	      T_max = 10;
	       inters = 0;
           	glaob.fintess = 10000000.0;
             iinit=false;
            if(!iinit)
            {
                 costmap_ros_ = costmap_ros;
            costmap_ = costmap_ros_->getCostmap();

            ros::NodeHandle private_nh("~/" + name);
            _plan_pub = private_nh.advertise<nav_msgs::Path>("global_plan", 1);
            _frame_id = costmap_ros->getGlobalFrameID();
             originX = costmap_->getOriginX();
            originY = costmap_->getOriginY();
			width = costmap_->getSizeInCellsX();
            height = costmap_->getSizeInCellsY();
            x_max=float(width-200);
            x_min=200.0;
            y_max=float(height-150);
             y_min=150.0;
			ROS_INFO("width:%d,heeight:%d",width,height);
			
            for ( int ix= 0; ix < width; ix++)
            {
                for (int iy= 0; iy< height; iy++)
                {
                      cost = static_cast<int>(costmap_->getCost(ix, iy));
                      if(cost>0)
                      {
                          cost=1;
                      }
                  //  x.push_back(cost);
                  ma.push_back(cost);
				
                }
                map.push_back(ma);
                ma.clear();
                
            }	
			 resolution = costmap_->getResolution();
			 ROS_INFO("ACO planner initialized successfully");
          iinit = true;
    }
       else{
              ROS_WARN("This planner has already been initialized... doing nothing");
         }
            
      }
       bool wca::makePlan(const geometry_msgs::PoseStamped& start, const geometry_msgs::PoseStamped& goal,  std::vector<geometry_msgs::PoseStamped>& plan )
       { if (!iinit)
        {
            ROS_ERROR("The planner has not been initialized, please call initialize() to use the planner");
            return false;
        } 
        if (goal.header.frame_id != costmap_ros_->getGlobalFrameID())
        {
            ROS_ERROR("This planner as configured will only accept goals in the %s frame, but a goal was sent in the %s frame.",
                costmap_ros_->getGlobalFrameID().c_str(), goal.header.frame_id.c_str());
            return false;
        }  
         tf::Stamped<tf::Pose> goal_tf;
    tf::Stamped<tf::Pose> start_tf;
    poseStampedMsgToTF(goal, goal_tf);
    poseStampedMsgToTF(start, start_tf);
     float startX = start.pose.position.x;
    float startY = start.pose.position.y;
//ROS_INFO("stary=%.2f",startY);
        float goalX = goal.pose.position.x;
        float goalY = goal.pose.position.y;
        //ROS_INFO("goaly=%.2f",goalY);
        getCorrdinate(startX, startY);   //获取起点在世界坐标系下的坐标
        getCorrdinate(goalX, goalY);  
		ROS_INFO("s=%.2f,%.2f,g=%.2f,%.2f",startX,startY,goalX,goalY);
		//int kx=abs(int (startX/resolution/100)-int((goalX/resolution)/100));
		int ky=abs(int(startY/resolution/100)-int(goalY/resolution/100));
        if(startX!=goalX&&startY!=goalY)
       {
           index = 1;

           for (int k = 0; k < M; k++)
	        {
		        init(startX, startY, goalX, goalY);
		        calFitness();
	        }
           // index = 0;
			ROS_INFO("1");
            posinit();
       
    if(glaob.path.size()!=0)
    {
        for (int i = 0; i < glaob.path[0].size(); i++)
	{
					float x = 0.0;
                    float y = 0.0;

                    

                    geometry_msgs::PoseStamped pose = goal;

                    pose.pose.position.x =glaob.path[0][i]*  resolution +originX;
                    pose.pose.position.y = glaob.path[1][i]*resolution+originY;
                    pose.pose.position.z = 0.0;

                    pose.pose.orientation.x = 0.0;
                    pose.pose.orientation.y = 0.0;
                    pose.pose.orientation.z = 0.0;
                    pose.pose.orientation.w = 1.0;

                    plan.push_back(pose);

		//std::cout << "("<<my_A.node[resut.path1[i]][0] << ","<<my_A.node[resut.path1[i]][1]<<")"<<std::endl;
	}
         nav_msgs::Path path;
	     path.poses.resize(plan.size());  
          if (plan.empty())
                {
                    //still set a valid frame so visualization won't hit transform issues
                    path.header.frame_id = _frame_id;
                    path.header.stamp = ros::Time::now();
                }
                else
                {
                    path.header.frame_id = plan[0].header.frame_id;
                    path.header.stamp = plan[0].header.stamp;
                }       
                     for (int i = 0; i < plan.size(); i++)
                {
                    path.poses[i] = plan[i];
                }
				    for (int i = 0; i < plan.size(); i++)
                {
                    path.poses[i] = plan[i];
                }
      ROS_INFO("7");
                _plan_pub.publish(path);
			   ROS_INFO("The planner find a path......, ");
			  
partic.pos1.x.clear();
	partic.path.clear();
	partic.v1.x.clear();
	partic.v1.y.clear();
	partic.pos1.x.clear(); partic.best.pos2.x.clear();
	partic.pos1.y.clear(); partic.best.pos2.y.clear();
	partic.best.path.clear();

	glaob.path.clear();
	glaob.poss.x.clear();
	glaob.poss.y.clear();
	glaob.fintess=100000.0;
	par.clear();
	//path.poses.clear();
    return true;

    }
    else{
        ROS_WARN("The planner failed to find a path, choose other goal position");
               partic.pos1.x.clear();
	partic.path.clear();
	partic.v1.x.clear();
	partic.v1.y.clear();
	partic.pos1.x.clear(); partic.best.pos2.x.clear();
	partic.pos1.y.clear(); partic.best.pos2.y.clear();
	partic.best.path.clear();

	glaob.path.clear();
	glaob.poss.x.clear();
	glaob.poss.y.clear();
	glaob.fintess=100000.0;
	par.clear();
                return false;
    }

       } 
       else
       {
           ROS_WARN("Not valid start or goal");
             partic.pos1.x.clear();
	partic.path.clear();
	partic.v1.x.clear();
	partic.v1.y.clear();
	partic.pos1.x.clear(); partic.best.pos2.x.clear();
	partic.pos1.y.clear(); partic.best.pos2.y.clear();
	partic.best.path.clear();

	glaob.path.clear();
	glaob.poss.x.clear();
	glaob.poss.y.clear();
	glaob.fintess=100000.0;
	par.clear();
            return false;
       }

       }
           void wca::getCorrdinate (float& x, float& y)
     {
         x = x - originX;
        y = y - originY;
     }
     void wca::init(float s_x, float s_y, float e_x, float e_y)
{
	float ran1;
	float ran2;
	start_x = s_x/resolution;
	start_y = s_y/resolution ;
	end_x = e_x/resolution ;
	end_y = e_y/resolution ;
	for (int k = 0; k < pointNum; k++)
	{
		//	ROS_INFO("1");
		if (int(end_x - start_x) >= 0 && int(end_y - start_y) >= 0)
		{
			if (k == 0)
			{
				if (int(end_x - start_x) == 0)
				{
					ran1 = start_x;
				}
				else {
					ran1 = float(rand() % (int(end_x - start_x)) + int(start_x));
				}

				//ROS_INFO("ran1%.2f",ran1);
				if (int(end_y - start_y) == 0)
				{
					ran2 = end_y;
				}
				else
				{
					ran2 = float(rand() % (int(end_y - start_y)) + int(start_y));
				}

				//ROS_INFO("ran2%.2f",ran2);
			}
			else {
				if (int(end_x - partic.pos1.x[k - 1]) == 0)
				{
					ran1 = float(rand() % (int(end_x - partic.pos1.x[k - 1]) + 1) + int(partic.pos1.x[k - 1]));
					//ROS_INFO("ran3%.2f",ran1);
				}
				else {
					ran1 = float(rand() % (int(end_x - partic.pos1.x[k - 1])) + int(partic.pos1.x[k - 1]));
					//ROS_INFO("ran4%.2f",ran1);
				}
				if (int(end_y - partic.pos1.y[k - 1]) == 0)
				{
					ran2 = float(rand() % (int(end_y - partic.pos1.y[k - 1]) + 1) + int(partic.pos1.y[k - 1]));
					//ROS_INFO("ran5%.2f",ran2);
				}
				else
				{
					ran2 = float(rand() % (int(end_y - partic.pos1.y[k - 1])) + int(partic.pos1.y[k - 1]));
					//ROS_INFO("ran5%.2f",ran2);
				}


			}
			while (map[int(ran1)][int(ran2)] == 1)
			{
				ran1 = float(rand() % (int(end_x - start_x)) + int(start_x));
				ran2 = float(rand() % (int(end_y - start_y)) + int(start_y));
			}
		}
		else if (int(end_x - start_x) <= 0 && int(end_y - start_y) <= 0)
		{
			//ROS_INFO("2");
			if (k == 0)
			{
				if (int(start_x - end_x) == 0)
				{
					ran1 = start_x;
				}
				else
				{
					ran1 = float(rand() % (int(start_x - end_x)) + int(end_x));
				}
				if (int(start_y - end_y) == 0)
				{
					ran2 = start_y;
				}
				else {
					ran2 = float(rand() % (int(start_y - end_y)) + int(end_y));
				}

			}
			else {
				//std::cout << partic.pos1.x[k - 1] - end_x+end_x<<" ";
				//ran1 = 0;
				//ran2 = 0;
				if (int(partic.pos1.x[k - 1] - end_x) == 0)
				{
					ran1 = float(rand() % (int(partic.pos1.x[k - 1] - end_x) + 1) + end_x);
				}
				else
				{
					ran1 = float(rand() % (int(partic.pos1.x[k - 1] - end_x)) + end_x);
				}
				if (int(partic.pos1.y[k - 1] - end_y) == 0)
				{
					ran2 = float(rand() % (int(partic.pos1.y[k - 1] - end_y) + 1) + end_y);
				}
				else
				{
					ran2 = float(rand() % (int(partic.pos1.y[k - 1] - end_y)) + end_y);
				}
			}
			while (map[int(ran1)][int(ran2)] == 1)
			{
				ran1 = float(rand() % (int(start_x - end_x) + 1) + int(end_x));
				ran2 = float(rand() % (int(start_y - end_y) + 1) + int(end_y));
			}

		}
		else if ((end_x - start_x) >= 0 && (end_y - start_y) <= 0)
		{
			//ROS_INFO("3");
			if (k == 0)
			{
				if (int(start_x - end_x) == 0)
				{
					ran1 = start_x;
				}
				else
				{
					ran1 = float(rand() % (int(end_x - start_x)) + int(start_x));
				}
				if (int(start_y - end_y) == 0)
				{
					ran2 = start_y;
				}
				else {
					ran2 = float(rand() % (int(start_y - end_y)) + int(end_y));
				}


			}
			else {
				if (int(end_x - partic.pos1.x[k - 1]) == 0)
				{
					ran1 = float(rand() % (int(end_x - partic.pos1.x[k - 1]) + 1) + int(partic.pos1.x[k - 1]));
				}
				else
				{
					ran1 = float(rand() % (int(end_x - partic.pos1.x[k - 1])) + int(partic.pos1.x[k - 1]));
				}
				if (int(partic.pos1.y[k - 1] - end_y) == 0)
				{
					ran2 = float(rand() % (int(partic.pos1.y[k - 1] - end_y) + 1) + end_y);
				}
				else {
					ran2 = float(rand() % (int(partic.pos1.y[k - 1] - end_y)) + end_y);
				}
				//ran2 = float(rand() % (int(partic.pos1.y[k - 1] - end_y) + 1) + end_y);
			}
			while (map[int(ran1)][int(ran2)] == 1)
			{
				ran1 = float(rand() % (int(end_x - start_x)) + int(start_x));
				ran2 = float(rand() % (int(start_y - end_y)) + int(end_y));
			}
		}
		else {
			//ROS_INFO("4");
			if (k == 0)
			{
				if (int(start_x - end_x) == 0.0)
				{
					ran1 = start_x;
				}
				else
				{
					ran1 = float(rand() % (int(start_x - end_x)) + int(end_x));
				}
				if (int(start_y - end_y) == 0.0)
				{
					ran2 = start_y;
				}
				else {
					ran2 = float(rand() % (int(end_y - start_y)) + int(start_y));
				}

			}
			else {
				if (int(partic.pos1.x[k - 1] - end_x) == 0)
				{
					ran1 = float(rand() % (int(partic.pos1.x[k - 1] - end_x) + 1) + end_x);
				}
				else
				{
					ran1 = float(rand() % (int(partic.pos1.x[k - 1] - end_x)) + end_x);
				}
				if (int(end_y - partic.pos1.y[k - 1]) == 0)
				{
					ran2 = float(rand() % (int(end_y - partic.pos1.y[k - 1]) + 1) + int(partic.pos1.y[k - 1]));
				}
				else {
					ran2 = float(rand() % (int(end_y - partic.pos1.y[k - 1])) + int(partic.pos1.y[k - 1]));
				}

			}
			while (map[int(ran1)][int(ran2)] == 1)
			{
				ran1 = float(rand() % (int(start_x - end_x)) + int(end_x));
				ran2 = float(rand() % (int(end_y - start_y)) + int(start_y));
			}
		}

		partic.pos1.x.push_back(ran1);
		partic.pos1.y.push_back(ran2);
		partic.v1.x.push_back(0.0);
		partic.v1.y.push_back(0.0);
	}
}
void wca::calFitness()
{
	int l1 = 0, l2 = 0, l3 = 0, l4 = 0;
	int x = 0, y = 0, x1 = 0, y1 = 0;
	float dist = 0;
	int biao1 = 0, biao2 = 0;
	std::vector<float>x_seq, y_seq, X_seq, Y_seq;

	x_seq.push_back(start_x);
	y_seq.push_back(start_y);
	for (int i = 0; i < partic.pos1.x.size(); i++)
	{
		x_seq.push_back(partic.pos1.x[i]);
		y_seq.push_back(partic.pos1.y[i]);
	}
	x_seq.push_back(end_x);
	y_seq.push_back(end_y);
	X_seq.push_back(start_x);
	Y_seq.push_back(start_y);
	for (int i = 1; i < x_seq.size(); i++)
	{
		//std::cout << i;
		if (abs(x_seq[i] - x_seq[i - 1]) > abs(y_seq[i] - y_seq[i - 1]))
		{
			if (x_seq[i] > x_seq[i - 1])
			{
				l1 = int(x_seq[i - 1]);
				l2 = int(x_seq[i]);
			}
			else {
				l1 = int(x_seq[i]);
				l2 = int(x_seq[i - 1]);

				biao1 = X_seq.size();

			}
			for (int k = l1; k < l2; k++)
			{
				float k1 = 0;

				//y1 + (x - x1) * (y2 - y1) / (x2 - x1);
				if ((x_seq[i] - x_seq[i - 1]) == 0)
				{
					k1 = x_seq[i];
				}
				else {
					k1 = y_seq[i - 1] + (k - x_seq[i - 1]) * (y_seq[i] - y_seq[i - 1]) / (x_seq[i] - x_seq[i - 1]);
				}
				if (y_seq[i] > y_seq[i - 1])
				{
					if (k1 > y_seq[i])
					{
						k1 = y_seq[i];
					}
					if (k1 < y_seq[i - 1])
					{
						k1 = y_seq[i - 1];
					}
				}
				else
				{
					if (k1 < y_seq[i])
					{
						k1 = y_seq[i];
					}
					if (k1 > y_seq[i - 1])
					{
						k1 = y_seq[i - 1];
					}
				}
				if (x_seq[i] > x_seq[i - 1])
				{
					Y_seq.push_back(k1);
					X_seq.push_back(float(k));
				}
				else
				{
					Y_seq.insert(Y_seq.begin() + biao1, k1);
					X_seq.insert(X_seq.begin() + biao1, float(k));
				}

				//std::cout << int(x_seq[i])<<" ,"<< k1 << std::endl;
			}
			if (x_seq[i] >= x_seq[i - 1])
			{
				X_seq.push_back(x_seq[i]);
				Y_seq.push_back(y_seq[i]);
			}

		}
		else {
			if (y_seq[i] >= y_seq[i - 1])
			{
				l3 = int(y_seq[i - 1]);
				l4 = int(y_seq[i]);
			}
			else {
				l3 = int(y_seq[i]);
				l4 = int(y_seq[i - 1]);

				biao2 = Y_seq.size();
			}
			for (int k = l3; k < l4; k++)
			{
				float k1 = 0;

				if ((y_seq[i] - y_seq[i - 1]) == 0)
				{
					k1 = y_seq[i];
				}
				else {
					k1 = x_seq[i - 1] + (k - y_seq[i - 1]) * (x_seq[i] - x_seq[i - 1]) / ((y_seq[i] - y_seq[i - 1]));
				}
				if (x_seq[i] > x_seq[i - 1])
				{
					if (k1 > x_seq[i])
					{
						k1 = x_seq[i];
					}
					if (k1 < x_seq[i - 1])
					{
						k1 = x_seq[i - 1];
					}
				}
				else
				{
					if (k1 < x_seq[i])
					{
						k1 = x_seq[i];
					}
					if (k1 > x_seq[i - 1])
					{
						k1 = x_seq[i - 1];
					}
				}
				//std::cout << k1<<" ";
				if (y_seq[i] >= y_seq[i - 1])
				{
					X_seq.push_back(k1);
					Y_seq.push_back(k);
				}
				else {
					X_seq.insert(X_seq.begin() + biao2, k1);
					Y_seq.insert(Y_seq.begin() + biao2, k);
				}
			}
			if (y_seq[i] > y_seq[i - 1])
			{
				X_seq.push_back(x_seq[i]);
				Y_seq.push_back(y_seq[i]);
			}
		}
		X_seq.push_back(x_seq[i]);
		Y_seq.push_back(y_seq[i]);
		//std::cout << "------" << std::endl;

	}
	partic.path.push_back(X_seq);
	partic.path.push_back(Y_seq);
	for (int k = 1; k < partic.path[0].size(); k++)
	{
		if (partic.path[0][k] == partic.path[0][k - 1] && partic.path[1][k] == partic.path[1][k - 1])
		{
			partic.path[0].erase(partic.path[0].begin() + k);
			partic.path[1].erase(partic.path[1].begin() + k);
			k = 1;
		}
	}
	for (int k = 0; k < partic.path[0].size(); k++)
	{
		x = partic.path[0][k];
		y = partic.path[1][k];
		//std::cout << "(" << x << "," << y << ")" << std::endl;
		if (map[int(x)][int(y)] != 0)
		{
			partic.flag = 1;
			break;
		}


	}
	for (int k = 1; k < partic.path[0].size(); k++)
	{
		x1 = partic.path[0][k - 1];
		y1 = partic.path[1][k - 1];
		x = partic.path[0][k];
		y = partic.path[1][k];
		dist = dist + sqrt(pow(x - x1, 2) + pow(y - y1, 2));

	}
	if (partic.flag == 1)
	{
		partic.fitness = dist * 100;
	}
	else
	{
		partic.fitness = dist;
	}
	if (index == 1)
	{
		//std::cout << partic.pos1.x.size() << "";
		partic.best.pos2.x = partic.pos1.x;
		partic.best.pos2.y = partic.pos1.y;
		partic.best.fitness = partic.fitness;
		partic.best.path = partic.path;
		//std::cout << glaob.fintess <<" "<< partic.fitness<<std::endl;
		if (partic.fitness < glaob.fintess)
		{
			glaob.fintess = partic.best.fitness;
			glaob.path = partic.best.path;
			glaob.poss.x = partic.pos1.x;
			//std::cout << glaob.poss.x[0];
			glaob.poss.y = partic.pos1.y;
		}
	}
	if (par.size() < M)
	{
		//partic.pos1.x.size();
		par.push_back(partic);
		//par[0].pos1.x[0];
	}
	else if (par.size() == M)
	{
		par[inters].pos1 = partic.pos1;
		par[inters].fitness = partic.fitness;
		par[inters].path = partic.path;
	}
	partic.pos1.x.clear();
	partic.path.clear();
	partic.v1.x.clear();
	partic.v1.y.clear();
	partic.pos1.x.clear();// partic.best.pos.x.clear();
	partic.pos1.y.clear(); //partic.best.pos.y.clear();



}
void wca::posinit()
{
	wolfs_s.resize(int(S_num));
	wolfs_m.resize(int(M-S_num));
	partic.pos1.x.resize(pointNum);
	partic.pos1.y.resize(pointNum);
	float sum=0,sum1=0,d=0;
	index = 1;
	int size = par.size();
	for (int i = 0; i < size - 1; i++)
	{
		for (int j = 0; j < size - 1 - i; j++)
		{
			if (par[j].fitness > par[j + 1].fitness)
			{
				std::vector<particles>wca_l;
				wca_l.push_back(par[j]);
				par[j] = par[j + 1];
				par[j + 1] = wca_l[0];
				wca_l.clear();

			}

		}
	}
	for (int i = 0; i<int(S_num); i++)
	{
		wolfs_s[i] = par[i];
	}
	for (int i = int(S_num); i < M; i++)
	{
		wolfs_m[i - int(S_num)] = par[i];
	}
	for (int iter = 0; iter < N; iter++)
	{
		for (int i = 0; i < S_num; i++)
		{
			for (int k = 0; k < h; k++)
			{
				partic.pos1.x.resize(pointNum);
				partic.pos1.y.resize(pointNum);
				for (int p_s = 0; p_s < wolfs_s[i].pos1.x.size(); p_s++)
				{
					//std::cout << p_s;
					
					partic.pos1.x[p_s] = wolfs_s[i].pos1.x[p_s] + step_a * sin(2 * 3.14 * k / h);
					partic.pos1.y[p_s] = wolfs_s[i].pos1.y[p_s] + step_a * sin(2 * 3.14 * k / h);
					if (partic.pos1.x[p_s] > x_max)
					{
						partic.pos1.x[p_s] = x_max;
					}
					else if(partic.pos1.x[p_s] <x_min)
					{
						partic.pos1.x[p_s] = x_min;
					}
					if (partic.pos1.y[p_s] > y_max)
					{
						partic.pos1.y[p_s] = y_max;
					}
					else if (partic.pos1.y[p_s] < y_min)
					{
						partic.pos1.y[p_s] = y_min;
					}
				}
				inters = 0;
				calFitness();
				if (par[0].fitness < wolfs_s[i].fitness)
				{
					wolfs_s[i] = par[0];
				}


			}
		}
		for (int i = 0; i<int(M_num); i++)
		{
			for (int k = 0; k < h; k++)
			{
				for (int l = 0; l < wolfs_m[i].pos1.x.size(); l++)
				{
					sum = sum + pow(wolfs_m[i].pos1.x[l] - glaob.poss.x[l], 2);
					sum1 = sum1 + pow(wolfs_m[i].pos1.y[l] - glaob.poss.y[l], 2);
				}
				if (sum == 0 && sum1 == 0)
				{
					continue;
				}
				partic.pos1.x.resize(pointNum);
				partic.pos1.y.resize(pointNum);
				for (int l = 0; l < wolfs_m[i].pos1.x.size(); l++)
				{
					if (sum == 0)
					{
						sum = 1;
					}
					if (sum1 == 0)
					{
						sum1 = 1;
					}

					partic.pos1.x[l] = wolfs_m[i].pos1.x[l] + step_b * (glaob.poss.x[l] - wolfs_m[i].pos1.x[l]) / sqrt(sum);
					partic.pos1.y[l]= wolfs_m[i].pos1.y[l] + step_b * (glaob.poss.y[l] - wolfs_m[i].pos1.y[l]) / sqrt(sum1);
					if (partic.pos1.x[l] > x_max)
					{
						partic.pos1.x[l] = x_max;
					}
					else if (partic.pos1.x[l] < x_min)
					{
						partic.pos1.x[l] = x_min;
					}
					if (partic.pos1.y[l] > y_max)
					{
						partic.pos1.y[l] = y_max;
					}
					else if (partic.pos1.y[l] < y_min)
					{
						partic.pos1.y[l] = y_min;
					}
				}

				inters = 0;
				calFitness();
				if (par[0].fitness < wolfs_m[i].fitness)
				{
					wolfs_m[i] = par[0];
				}
				sum = 0;
				sum1 = 0;
				for (int l = 0; l < par[0].pos1.x.size(); l++)
				{
					sum = sum + pow(wolfs_m[i].pos1.x[l] - glaob.poss.x[l], 2);
					sum1 = sum1 + pow(wolfs_m[i].pos1.y[l] - glaob.poss.y[l], 2);
				}
				d = sqrt(sum + sum1);
				if (d < d0)
				{
					for (int tm = 0; tm < T_max; tm++)
					{
						partic.pos1.x.resize(pointNum);
						partic.pos1.y.resize(pointNum);
						for (int l = 0; l < par[0].pos1.x.size(); l++)
						{
							if (sum == 0)
							{
								sum = 1;
							}
							if (sum1 == 0)
							{
								sum1 = 1;
							}
							partic.pos1.x[l] = wolfs_m[i].pos1.x[l] + step_b*(rand()%100/100.0) * (glaob.poss.x[l] - wolfs_m[i].pos1.x[l]) / sqrt(sum);
							partic.pos1.y[l] = wolfs_m[i].pos1.y[l] + step_b * (rand() % 100 / 100.0)*(glaob.poss.y[l] - wolfs_m[i].pos1.y[l]) / sqrt(sum1);
							if (partic.pos1.x[l] > x_max)
							{
								partic.pos1.x[l] = x_max;
							}
							else if (partic.pos1.x[l] < x_min)
							{
								partic.pos1.x[l] = x_min;
							}
							if (partic.pos1.y[l] > y_max)
							{
								partic.pos1.y[l] = y_max;
							}
							else if (partic.pos1.y[l] < y_min)
							{
								partic.pos1.y[l] = y_min;
							}
						}
						inters = 0;
						calFitness();
						if (par[0].fitness < wolfs_m[i].fitness)
						{
							wolfs_m[i] = par[0];
						}
					}
				}
			}

		}
	}
	wolfs_s.clear();
	wolfs_m.clear();
	par.clear();

}


};