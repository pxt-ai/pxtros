#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<netdb.h>
#include<string>
#include"ros/ros.h"
#include"actionlib/client/simple_action_client.h"
#include"move_base_msgs/MoveBaseAction.h"
#include"geometry_msgs/Twist.h"
#include"geometry_msgs/PointStamped.h"
#include"geometry_msgs/PoseWithCovarianceStamped.h"
#include"sensor_msgs/LaserScan.h"
#include"sensor_msgs/PointCloud2.h"
#include<nav_msgs/Odometry.h>
#include<nav_msgs/OccupancyGrid.h>
#include<nav_msgs/Path.h>
#include<nav_msgs/GetPlan.h>
#include<tf/tf.h>
#include<tf/transform_listener.h>
#include<tf/transform_datatypes.h>
#include<boost/foreach.hpp>
#include<costmap_2d/costmap_2d_ros.h>
#include<costmap_2d/costmap_2d.h>
#include<nav_core/base_global_planner.h>
#include<angles/angles.h>
#include<base_local_planner/world_model.h>
#include<base_local_planner/costmap_model.h>
#include<set>
#include<vector>
using namespace std;
using std::string;
#ifndef BASTER_STAR_A_CPP
#define BASTER_STAR_A_CPP
struct cells
{
int currentCell;
float fCost;
};
namespace BAstar_planner
{
    class BAstar_planner_ROS:public nav_core::BaseGlobalPlanner{
        public:
        BAstar_planner_ROS();
        BAstar_planner_ROS(ros::NodeHandle &);
        BAstar_planner_ROS(std::string name,costmap_2d::Costmap2DROS *costmap_ros);
        ros::NodeHandle ROSNodeHandl;
        ros::Publisher plan_pub;
        string frame_id;
        void initialize(string name,costmap_2d::Costmap2DROS* costmap_2d);
        bool makePlan(const geometry_msgs::PoseStamped& start,const geometry_msgs::PoseStamped &goal,vector<geometry_msgs::PoseStamped> &plan);
        void getCorrdinate(float &x,float &y);
        int convertToCellIndex(float x,float y);
        void convertToCoordinate(int index, float &x,float &y);
        bool isCellInsideMap(float x,float y);
        void mapToWorld(double mx,double my,double  &wx,double &wy);
        vector<int> BAstarPlanner(int startCell,int goalCell);
        vector<int> findPath(int startCell,int goalCell,float g_score[]);
        vector<int>constructPath(int startCell,int goalCell,float g_score[]);
        float calculateHCost(int cellID,int goalCell);
        void addNeighborCellToOpenList(multiset<cells> &OPL,int neighborCell,int goalCell,float g_score[]);
        vector<int>findFreeNeighbor(int CellID);
        bool isStarAndGoalCellsValid(int startCell,int goalCell);
        float getMoveCost(int CellId1,int CellID2);
        float getMoveCost(int i1,int j1,int i2,int j2);
        bool isFree(int CellD);
        bool isFree(int i,int j);
        int getCellIndex(int i,int j)
        {
            return (i*width)+j;
        }
        int getCellRowID(int index)
        {
            return index/width;
        }
        int getCellColID(int index)
        {
            return index%width;
        }
        float originX;
        float originY;
        float resolution;
        costmap_2d::Costmap2DROS *costmap_ros_;
        double step_size,min_dist_from_robot_;
        costmap_2d::Costmap2D *costmap_;
        bool initialized_;
        int width;
        int height;
    
    };
};

#endif;