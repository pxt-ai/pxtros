#!/bin/bash
source ./devel/setup.bash
roslaunch tianbot_mini simulation.launch &
sleep 10
source ./devel/setup.bash
roslaunch tianbot_mini amcl.launch &
sleep 20
source ./devel/setup.bash
rosrun pso_duomub pso_du



