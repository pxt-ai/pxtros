#include <iostream>
#include <string>
#include <fstream>
#include <time.h>
#include <random>
#include <vector>  
#include <cmath>  
#include <limits>
#include<algorithm>
#include"ros/ros.h"
// geometry_msgs/PoseStamped
 #include"geometry_msgs/PoseStamped.h" 
 #include"std_msgs/Header.h"
 #include"std_msgs/UInt32.h"
 #include"std_msgs/Time.h"
 #include"std_msgs/Float64.h"
 #include"std_msgs/String.h"
using namespace std;

const int citycount =4;
double vmax = 1, vmin = -1;
class  actions{
public:

u_int32_t  seq;

std::string frame_id;
ros::Time stamp;
float x,y,z=0,x1=0,y1=0,z1,w1;

actions(u_int32_t   seq,ros::Time stamp,std::string frame_id,float x,float y,float z,float x1,float y1,float z1,float w1)
{

this->seq=seq;
this->stamp=stamp;
this->frame_id=frame_id;
this->x=x;
this->y=y;
this->z=z;
this->x1=x1;
this->y1=x1;
this->z1=z1;
this->w1=w1;



}

};
std::vector<actions> v1;
struct Point {
	double x, y;
	Point(double x_, double y_) : x(x_), y(y_) {}
};

// 计算两点之间的欧氏距离的平方  
double distanceSquared(const Point& a, const Point& b) {
	return std::pow(a.x - b.x, 2) + std::pow(a.y - b.y, 2);
}

// 根据已知质心分组数据点  
std::vector<std::vector<Point>> groupPointsByCentroids(const std::vector<Point>& points, const std::vector<Point>& centroids) {
	std::vector<std::vector<Point>> clusters(centroids.size());

	// 分配点到最近的质心  
	for (const auto& p : points) {
		double minDist = std::numeric_limits<double>::max();
		int minIndex = -1;
		for (size_t i = 0; i < centroids.size(); ++i) {
			double dist = distanceSquared(p, centroids[i]);
			if (dist < minDist) {
				minDist = dist;
				minIndex = static_cast<int>(i);
			}
		}
		clusters[minIndex].push_back(p); // 将点添加到对应的组  
	}

	return clusters;
}
class City
{
public:
	string name;//城市名称
	double x, y;//城市点的二维坐标
	void shuchu()
	{
		//std::cout << name + ":" << "(" << x << "," << y << ")" << endl;
	}
};
class Graph
{
public:
	City city[citycount];//城市数组
	double distance[citycount][citycount];//城市间的距离矩阵
	void Readcoordinatetxt(std::vector<pair<float, float>>x_y)//读取城市坐标文件的函数
	{
		
			int i = 0;
			for(int j=0;j<x_y.size();j++)
			{
				city[j].name = to_string(j+1);//城市名称转化为字符串
				city[j].x = x_y[j].first;
				city[j].y = x_y[j].second;
				
			}
	
		for (int i = 0; i < citycount; i++)
			for (int j = 0; j < citycount; j++)
			{
				distance[i][j] = sqrt((pow((city[i].x - city[j].x), 2) + pow((city[i].y - city[j].y), 2)) / 10.0);//计算城市ij之间的伪欧式距离
				if (round(distance[i][j] < distance[i][j]))distance[i][j] = round(distance[i][j]) + 1;
				else distance[i][j] = round(distance[i][j]);
			}
	}
	void shuchu()
	{
		cout << "城市名称 " << "坐标x" << " " << "坐标y" << endl;
		for (int i = 0; i < citycount; i++)
			city[i].shuchu();
		/*cout << "距离矩阵： " << endl;
		for (int i = 0; i < citycount; i++)
		{
			for (int j = 0; j < citycount; j++)
			{
				if (j == citycount - 1)
					std::cout << distance[i][j] << endl;
				else
					std::cout << distance[i][j] << "  ";
			}
		}*/
	}
};
Graph Map_City;//定义全局对象图,放在Graph类后
int* Random_N(int n)
{
	int* geti;
	geti = new int[n];
	int j = 0;
	while (j < n)
	{
		while (true)
		{
			int flag = -1;
			int temp = rand() % n + 1;
			if (j > 0)
			{
				int k = 0;
				for (; k < j; k++)
				{
					if (temp == *(geti + k))break;
				}
				if (k == j)
				{
					*(geti + j) = temp;
					flag = 1;
				}
			}
			else
			{
				*(geti + j) = temp;
				flag = 1;
			}
			if (flag == 1)break;
		}
		j++;
	}
	return geti;
}
double Evaluate(int* x)//计算粒子适应值的函数
{
	double fitnessvalue = 0;
	for (int i = 0; i < citycount - 1; i++)
		fitnessvalue += Map_City.distance[x[i] - 1][x[i + 1] - 1];
	fitnessvalue += Map_City.distance[x[citycount - 1] - 1][x[0] - 1];
	return fitnessvalue;
}
class Particle
{
public:
	int* x;//粒子的位置
	float* v;//粒子的速度
	double fitness;
	void Init()
	{
		x = new int[citycount];
		v = new float[citycount];
		int* M = Random_N(citycount);
		for (int i = 0; i < citycount; i++)
			x[i] = *(M + i);
		fitness = Evaluate(x);
		for (int i = 0; i < citycount; i++)
		{
			v[i] = (rand()%2000-1000)/1000.0;
			cout << v[i] << " ";
		}
	}
	void shuchu()
	{
		for (int i = 0; i < citycount; i++)
		{
			if (i == citycount - 1)
			   std::cout << x[i] << ") = " << fitness << endl;
			else if (i == 0)
				std::cout << "f(" << x[i] << ",";
			else
			   std::cout << x[i] << ",";
		}
	}
};
void Adjuxt_validParticle(Particle p)//调整粒子有效性的函数，使得粒子的位置符合TSP问题解的一个排列
{
	int route[citycount];//1-citycount
	bool flag[citycount];//对应route数组中是否在粒子的位置中存在的数组，参考数组为route
	int biaoji[citycount];//对粒子每个元素进行标记的数组,参考数组为粒子位置x
	for (int j = 0; j < citycount; j++)
	{
		route[j] = j + 1;
		flag[j] = false;
		biaoji[j] = 0;
	}
	//首先判断粒子p的位置中是否有某个城市且唯一，若有且唯一，则对应flag的值为true,
	for (int j = 0; j < citycount; j++)
	{
		int num = 0;
		for (int k = 0; k < citycount; k++)
		{
			if (p.x[k] == route[j])
			{
				biaoji[k] = 1;//说明粒子中的k号元素对应的城市在route中，并且是第一次出现才进行标记
				num++; break;
			}
		}
		if (num == 0) flag[j] = false;//粒子路线中没有route[j]这个城市
		else if (num == 1) flag[j] = true;//粒子路线中有route[j]这个城市
	}
	for (int k = 0; k < citycount; k++)
	{
		if (flag[k] == false)//粒子路线中没有route[k]这个城市，需要将这个城市加入到粒子路线中
		{
			int i = 0;
			for (; i < citycount; i++)
			{
				if (biaoji[i] != 1)break;
			}
			p.x[i] = route[k];//对于标记为0的进行替换
			biaoji[i] = 1;
		}
	}
}
class PSO
{
public:
	Particle* oldparticle;
	Particle* pbest, gbest;
	double c1, c2, w;
	int Itetime;
	int popsize;

	void Init(int Pop_Size, int itetime, double C1, double C2, double W)
	{
		Itetime = itetime;
		c1 = C1;
		c2 = C2;
		w = W;
		popsize = Pop_Size;
		oldparticle = new Particle[popsize];
		pbest = new Particle[popsize];
		for (int i = 0; i < popsize; i++)
		{
			oldparticle[i].Init();
			pbest[i].Init();
			for (int j = 0; j < citycount; j++)
			{
				pbest[i].x[j] = oldparticle[i].x[j];
				pbest[i].fitness = oldparticle[i].fitness;
			}
		}
		gbest.Init(); gbest.fitness = INFINITY;//为全局最优粒子初始化
		for (int i = 0; i < popsize; i++)
		{
			if (pbest[i].fitness < gbest.fitness)
			{
				gbest.fitness = pbest[i].fitness;
				for (int j = 0; j < citycount; j++)
					gbest.x[j] = pbest[i].x[j];
			}
		}
	}
	void Shuchu()
	{
		for (int i = 0; i < popsize; i++)
		{
			std::cout << "粒子" << i + 1 << "->";
			oldparticle[i].shuchu();
		}
	}
	vector<int> PSO_TSP(int Pop_size, int itetime, double C1, double C2, double W, double Vlimitabs, std::vector<pair<float,float>>x_y)
	{
		vector<int> indx;
		Map_City.Readcoordinatetxt(x_y);
		Map_City.shuchu();
		vmax = Vlimitabs; vmin = -Vlimitabs;
		Init(Pop_size, itetime, C1, C2, W);
		//std::cout << "初始化后的种群如下：" << endl;
		//Shuchu();
		
	
		for (int ite = 0; ite < Itetime; ite++)
		{
			w = w / Itetime;
			for (int i = 0; i < popsize; i++)
			{
				//更新粒子速度和位置
				for (int j = 0; j < citycount; j++)
				{
					w = w+(rand() % 200 - 100) / 50.0;
					oldparticle[i].v[j] = (w * oldparticle[i].v[j] + c1 * float(rand()%1000)/1000.0 * (pbest[i].x[j] - oldparticle[i].x[j]) + c2 * float(rand() % 1000) / 1000.0 * (gbest.x[j] - oldparticle[i].x[j]));
					if (oldparticle[i].v[j] > vmax)//粒子速度越界调整
						oldparticle[i].v[j] = vmax;
					else if (oldparticle[i].v[j] < vmin)
						oldparticle[i].v[j] = vmin;
					oldparticle[i].x[j] += oldparticle[i].v[j];
					if (oldparticle[i].x[j] > citycount)oldparticle[i].x[j] = citycount;//粒子位置越界调整
					else if (oldparticle[i].x[j] < 1) oldparticle[i].x[j] = 1;
				}
				//粒子位置有效性调整，必须满足解空间的条件
				Adjuxt_validParticle(oldparticle[i]);
				oldparticle[i].fitness = Evaluate(oldparticle[i].x);
				pbest[i].fitness = Evaluate(pbest[i].x);
				if (oldparticle[i].fitness < pbest[i].fitness)
				{
					for (int j = 0; j < citycount; j++)
						pbest[i].x[j] = oldparticle[i].x[j];
				}//更新单个粒子的历史极值
				for (int j = 0; j < citycount; j++)
					gbest.x[j] = pbest[i].x[j];//更新全局极值
				for (int k = 0; k < popsize && k != i; k++)
				{
					if (Evaluate(pbest[k].x) < Evaluate(gbest.x))
					{
						for (int j = 0; j < citycount; j++)
							gbest.x[j] = pbest[k].x[j];
						gbest.fitness = Evaluate(gbest.x);
					}
				}
			}
			w = W;
			std::cout << "第" << ite + 1 << "次迭代后的最好粒子：";
			
		    gbest.shuchu();
		}
		for (int i = 0; i < Pop_size - 1; i++)
		{
			indx.push_back(gbest.x[i]-1);
		}
		//outfile.close();
		return indx;
	}
};
PSO pso;
int c=0;
void subscriberCallback( const geometry_msgs::PoseStamped::ConstPtr   &msg )
{
  
  float x=msg->pose.position.x;
  //ROS_INFO("x:%f",x);
 
  float y=msg->pose.position.y;
   ROS_INFO("任务点%d,{x=%.2f,%.2f}",c+1,x,y);
  float z=msg->pose.position.z;
  float x1=msg->pose.orientation.x;
  float y1=msg->pose.orientation.y;
  float z1=msg->pose.orientation.z;
  float w1=msg->pose.orientation.w;
  u_int32_t seq =msg->header.seq;
  std::string frame_id =msg->header.frame_id;
  ros::Time stamp= msg->header.stamp;
  actions s1( seq, stamp,frame_id, x, y, z, x1, y1, z1, w1);
  v1.push_back(s1);
  c++;
 // ROS_INFO("ss%d",c);


}

int main(int argc, char * argv[])
{
	std::vector<pair<float, float>>point;
	std::pair<float, float> x_y;
	std::vector<Point> centroids;
	std::vector<Point> points;
	vector<int> indx,renw_idex;
	int cisu=0;
     ros::init(argc,argv,"tian1");
	 setlocale(LC_ALL, "");
	
	 ROS_INFO("第一个点为任务初始点");

     ros::NodeHandle nh;
     ros::Subscriber sub=nh.subscribe<geometry_msgs::PoseStamped>("/goal__t",10,&subscriberCallback);
       ros::Publisher pub=nh.advertise<geometry_msgs::PoseStamped>("/tianbot_mini/move_base_simple/goal",10);
      ros::Rate loop_rate(1);
	   while(ros::ok)
	  {
	    while(ros::ok)
        {
               loop_rate.sleep();
                ros::spinOnce();
             
              //  ROS_INFO("d%d",i);
                if(c==citycount)
                {
                  break;
                }
        }
	/*for (int i = 0; i < citycount; i++)
	{
		
		x_y.first = rand() % 2000;
		
		
		x_y.second = rand() % 2000;
		points.push_back({ x_y.first,x_y.second });
		point.push_back(x_y);

	}*/
	
	 for (std::vector<actions>::iterator it=v1.begin();it<v1.end();it++)
   {
     	x_y.first=it->x;
     	x_y.second =it->y;
		point.push_back(x_y);
   }
//	centroids.push_back(points[0]);
	//centroids.push_back(points[1]);
	//system("mode con cols=200");//改变宽高
	//system("color fc");//改变颜色
	//std::cout << "粒子群优化算法求解TSP旅行商问题" << endl;
	indx=pso.PSO_TSP(citycount+1, 200, 2, 2, 0.8, 3.0, point);
	ROS_INFO("优化前的任务顺序为：");
	for (int i = 0; i < indx.size(); i++)
	{
		cout << indx[i] << " ";
	}

	cout << endl;
	auto it = find(indx.begin(), indx.end(), 0);
	int index = it - indx.begin();
	for (int i = 0; i < citycount; i++)
	{
		renw_idex.push_back(indx[index]);
		index++;
		if (index == citycount)
		{
			index = 0;
		}
	}
	ROS_INFO("优化后的任务顺序为：");
	for(int i = 0; i < citycount; i++)
	{
		ROS_INFO("任务%d",renw_idex[i]);
	}
	 for(int  it=0;it<citycount;it++)
{
  geometry_msgs::PoseStamped  su;
  su.header.frame_id=v1[renw_idex[it]].frame_id;
 
  su.header.stamp=ros::Time::now();
  su.pose.position.x=v1[renw_idex[it]].x;
  su.pose.position.y=v1[renw_idex[it]].y;
  su.pose.position.z=v1[renw_idex[it]].z;
  su.pose.orientation.x=v1[renw_idex[it]].x1;
  su.pose.orientation.y=v1[renw_idex[it]].y1;
  su.pose.orientation.z=v1[renw_idex[it]].z1;
  su.pose.orientation.w=v1[renw_idex[it]].w1;
  cisu++;
 ROS_INFO("第%d任务开始工作",it+1);
 ros::Duration(3).sleep();
  pub.publish(su);
 ros::Duration(30).sleep();
}
ROS_INFO("回到任务初始点");
geometry_msgs::PoseStamped  su;
  su.header.frame_id=v1[renw_idex[0]].frame_id;
 
  su.header.stamp=ros::Time::now();
  su.pose.position.x=v1[renw_idex[0]].x;
  su.pose.position.y=v1[renw_idex[0]].y;
  su.pose.position.z=v1[renw_idex[0]].z;
  su.pose.orientation.x=v1[renw_idex[0]].x1;
  su.pose.orientation.y=v1[renw_idex[0]].y1;
  su.pose.orientation.z=v1[renw_idex[0]].z1;
  su.pose.orientation.w=v1[renw_idex[0]].w1;
  pub.publish(su);
 //ros::Duration(30).sleep();
	/*it = find(indx.begin(), indx.end(), 1);
	int index2 = it - indx.begin();
	cout << index << " " << index2 << endl;
	std::vector<std::vector<Point>> clusters = groupPointsByCentroids(points, centroids);
	if (clusters[0].size() > clusters[1].size())
	{
		if (index < index2)
		{

		}
		else
		{

		}
	}
	else
	{
		if (index < index2)
		{

		}
		else
		{

		}
	}
	// 输出分组结果（可选）  
	for (size_t i = 0; i < clusters.size(); ++i) {
		std::cout << "Cluster " << i << ":" << std::endl;
		for (const auto& p : clusters[i]) {
			//std::cout << "(" << p.x << ", " << p.y << ")" << std::endl;
			for (int k = 0; k < points.size(); k++)
			{
				if (points[k].x == p.x && points[k].y == p.y)
				{
					std::cout << k <<"  ";
				}
			}

		}
	}*/
	point.clear();
	
	centroids.clear();
	points.clear();
	indx.clear();
	renw_idex.clear();
	c=0;
	v1.clear();
	    // loop_rate.sleep();
              //  ros::spinOnce();
	  }
	return 0;
}
