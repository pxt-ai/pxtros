#ifndef RVIZ_PLUG_H
#define RVIZ_PLUG_H
#include<rviz/panel.h>
#include<QLineEdit>
#include<QTableWidget>
#include<QPushButton>
#include<QVBoxLayout>
#include<qwidget.h>
#include<QLabel>
#include<QGroupBox>
#include"ros/ros.h"
#include <QTimer>  
namespace rviz_table
{
  class table_:public rviz::Panel
  {
      Q_OBJECT
      public:
      table_(QWidget *parent=0);
      QTimer *timer;
      ~table_();
      public Q_SLOTS:
      void display();
      public:
          ros::NodeHandle nh1;
          ros::Publisher _plan_pub,pub;
           ros::Subscriber sub;
         QLineEdit  *Edit1,*Edit2,*Edit3,*Edit4,*Edit5,*Edit6;
          QLabel *lab1,*lab2,*lab3,*lab4,*lab5,*lab6;
         QTableWidget *table_di;
         QPushButton   *puss;
          QTableWidget *tableWidget_ ;
          QVBoxLayout *topy;

  };
}
#endif