#include"rviz_plug.h"
#include<QVBoxLayout>
#include<QLabel>
#include<QWidget>
#include <rviz/display_context.h>  
#include <rviz/visualization_manager.h>  
#include <rviz/properties/property.h>  
#include <std_msgs/String.h>  
namespace rviz_table
{table_::table_(QWidget* parent):rviz::Panel(parent)
{
    timer =new QTimer(this);
    this->setFixedSize(350, 200); 
  // ros::NodeHandle nh;
    //nh.initNode();
  pub=nh1.advertise<std_msgs::String>("goal",10);

Edit1=new QLineEdit(this);
lab1=new QLabel("数据1",this);
Edit1->move(150,20);
lab1->move(50,20);
Edit2=new QLineEdit(this);
lab2=new QLabel("数据2",this);
lab2->move(50,40);
Edit2->move(150,40);
lab3=new QLabel("数据3",this);
lab3->move(50,60);
Edit3=new QLineEdit(this);
Edit3->move(150,60);
lab4=new QLabel("数据4",this);
Edit4=new QLineEdit(this);
lab4->move(50,80);
Edit4->move(150,80);
Edit5=new QLineEdit(this);
Edit5->move(150,100);
lab5=new QLabel("数据5",this);
lab5->move(50,100);
Edit6=new QLineEdit(this);
lab6=new QLabel("数据6",this);
lab6->move(50,120);
Edit6->move(150,120);
//topy=new  QVBoxLayout(this);
puss=new QPushButton("按钮",this);
  puss->move(90,170);
//topy->addWidget(puss);
connect(timer,&QTimer::timeout,this,&table_::display);
connect(puss,&QPushButton::pressed,this,&table_::display);
  timer->start(1000);


}
table_::~table_()
{

        //delete  out;
       delete table_di;
         delete puss;
          delete  tableWidget_ ;
          delete  topy;
}
void table_::display()
{
     std_msgs::String msg;  
        msg.data = "Hello from RViz Plugin!";  
        pub.publish(msg);  
       /* tableWidget_->clear(); // 清除表格中的所有内容  
    tableWidget_->setRowCount(0); // 将行数设置为 0，清除所有行  
  
    // 模拟一些新数据  
    QList<QList<QString>> data;  
    data << (QList<QString>() << "数据1" << "数据2" << "数据3");  
    data << (QList<QString>() << "数据4" << "数据5" << "数据6");  
    // ... 添加更多数据  
  
    // 设置新的行数和列数  
    int rows = data.size();  
    if (rows > 0) {  
        int cols = data[0].size();  
        tableWidget_->setRowCount(rows);  
        tableWidget_->setColumnCount(cols);  
  
        // 设置表头  
        QStringList headerLabels;  
        for (int i = 0; i < cols; ++i) {  
            headerLabels << QString("列 %1").arg(i + 1);  
        }  
        tableWidget_->setHorizontalHeaderLabels(headerLabels);  
  
        // 填充表格数据  
        for (int row = 0; row < rows; ++row) {  
            for (int col = 0; col < cols; ++col) {  
                QTableWidgetItem *newItem = new QTableWidgetItem(data[row][col]);  
                tableWidget_->setItem(row, col, newItem);  
            }  
        }  
    }  */
}

}
#include <pluginlib/class_list_macros.h>
PLUGINLIB_EXPORT_CLASS(rviz_table::table_,rviz::Panel )