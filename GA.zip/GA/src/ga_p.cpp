#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <string>
#include <cmath>
#include <time.h>
#include <random>
#include <vector>
#include "ga_p.h"
#include<algorithm>
#include <numeric>
#define ee 2.71828
#include <pluginlib/class_list_macros.h>
PLUGINLIB_EXPORT_CLASS(GA_planner::GA, nav_core::BaseGlobalPlanner)
  std::vector<unsigned int>x;

 std::vector<float> nn;
namespace GA_planner
{
    GA::GA()
    { }

    GA::GA(ros::NodeHandle &nh)
    {
         ROSNodeHandle = nh;
    }
    GA::GA(std::string name, costmap_2d::Costmap2DROS* costmap_ros)
    {
         initialize(name,  costmap_ros);
    }
     void GA::initialize(std::string name, costmap_2d::Costmap2DROS *costmap_ros)
     {
         iinit=false;
         float lb=0.6;
	     float ub = 1.2;
        int cost=1;
	   int zhangaiw = 0;
         if(!iinit)
         {

		 costmap_ros_ = costmap_ros;
            costmap_ = costmap_ros_->getCostmap();

            ros::NodeHandle private_nh("~/" + name);
            _plan_pub = private_nh.advertise<nav_msgs::Path>("global_plan", 1);
            _frame_id = costmap_ros->getGlobalFrameID();
             originX = costmap_->getOriginX();
            originY = costmap_->getOriginY();
			width = costmap_->getSizeInCellsX();
            height = costmap_->getSizeInCellsY();
			ROS_INFO("width:%d,heeight:%d",width,height);
			z.clear();
            for ( int ix= 0; ix < width; ix++)
            {
                for (int iy= 0; iy< height; iy++)
                {
                      cost = static_cast<int>(costmap_->getCost(ix, iy));
                  //  x.push_back(cost);
				
					if (cost== 0)
					{
						//ROS_INFO("ix.%d,iy,%d",ix,iy);
						//std::cout << "(" << i << "," << j << ") " << i * 40 + j - zhangaiw << std::endl;
						z.push_back(float(ix));
						z.push_back(float(iy));
						z.push_back(float(zhangaiw));
						zhangaiw1.push_back(z);
						//ROS_INFO("z1=%d,z2==%d",z[0],z[1]);
				
						z.clear();
			}
			
	
			else
			{
				zhangaiw++;
				//std::cout << zhangaiw << std::endl;
				//ROS_INFO("xhang%d",zhangaiw);
			}
                }
                //my_A.map.push_back(x);
		        //x.clear();
            }
			ROS_INFO("Initializing in progress, please wait......");
			int rongqi = 0;
	
	for ( int i= 0; i <width; i++)
	{
		
		for (int j= 0; j< height; j++)
		{
			//unsigned int cost = static_cast<int>(costmap_->getCost(i, j));
			//x.push_back(a[i][j]);
			cost = static_cast<int>(costmap_->getCost(i, j));
			if (cost== 0)
			{
				for (int a = 0; a < zhangaiw1.size(); a++)
				{
					if (int(zhangaiw1[a][0])== i && int(zhangaiw1[a][1]) == j)
					{
						zhangaiw = int(zhangaiw1[a][2]);
						break;
					}
				}
				//std::cout << "(" << i << "," << j << ") " << i * 40 + j - zhangaiw << std::endl;
				nn.push_back(float(rongqi));
				nn.push_back(float(i * height + j - zhangaiw));
				//ROS_INFO("%d",i * width + j - zhangaiw);
				nn.push_back(float(0.0));
				net1.push_back(nn);
				nn.clear();
				cost = static_cast<int>(costmap_->getCost(i+1, j));
				if ((i + 1) < width && cost==0)
				{
					for (int a = 0; a < zhangaiw1.size(); a++)
					{
						if (int(zhangaiw1[a][0]) == (i + 1) && int(zhangaiw1[a][1])== j)
						{
							zhangaiw = int(zhangaiw1[a][2]);
							break;
						}
					}
					nn.push_back(float(rongqi));
					nn.push_back(float((i + 1) * height+ j - zhangaiw));
					//ROS_INFO("%d",(i+1) * width + j - zhangaiw);
					//ROS_INFO("%d,%d,(%d,%d)",i+1,j,int(zhangaiw1[(i + 1) * height+ j - zhangaiw][0]),int(zhangaiw1[(i + 1) * height+ j - zhangaiw][1]));
					nn.push_back(float(1.0));
					net1.push_back(nn);
					nn.clear();
					//std::cout << "(" << i + 1 << "," << j << ") " << (i + 1) * 40 + j - zhangaiw << std::endl;
				}
				cost=static_cast<int>(costmap_->getCost(i-1, j));
				if ((i - 1) >= 0 &&  cost==0)
				{
					for (int a = 0; a < zhangaiw1.size(); a++)
					{
						if (int(zhangaiw1[a][0] )== (i - 1) && int(zhangaiw1[a][1] )== j)
						{
							
							zhangaiw = int(zhangaiw1[a][2]);
							break;
						}
					}
					nn.push_back(float(rongqi));
					nn.push_back(float((i - 1) * height+ j - zhangaiw));
					//ROS_INFO("%d",(i-1) * width + j - zhangaiw);
					nn.push_back(float(1.0));
					net1.push_back(nn);
					nn.clear();
					//std::cout << "(" << i - 1 << "," << j << ") " << (i - 1) * 40 + j - zhangaiw << std::endl;
				}
				else
				{
				}
				cost=static_cast<int>(costmap_->getCost(i, j+1));
				if ((j + 1) < height && cost==0 )
				{
					zhangaiw = 0;
					for (int a = 0; a < zhangaiw1.size(); a++)
					{
						if (int(zhangaiw1[a][0]) == i && int(zhangaiw1[a][1]) == (j + 1))
						{
							
							zhangaiw = int(zhangaiw1[a][2]);
							
							break;
						}
					}
					nn.push_back(float(rongqi));
					nn.push_back(float(i * height+ j + 1 - zhangaiw));
					//ROS_INFO("%d",i * width + j +1- zhangaiw);
					nn.push_back(float(1.0));
					net1.push_back(nn);
					nn.clear();
					//std::cout << zhangaiw << " ";
					//std::cout << "(" << i << "," << j+1 << ") " << i * 40 + j + 1 - zhangaiw << std::endl;
				}
				else
				{
				}
				cost=static_cast<int>(costmap_->getCost(i, j-1));
				if ((j - 1) >= 0 &&cost==0 )
				{
					for (int a = 0; a < zhangaiw1.size(); a++)
					{
						if (int(zhangaiw1[a][0] )== i && int(zhangaiw1[a][1]) == (j - 1))
						{
							//std::cout << zhangaiw << " ";
							zhangaiw = int(zhangaiw1[a][2]);
							break;
						}
					}
					nn.push_back(float(rongqi));
					nn.push_back(float(i *height+ j - 1 - zhangaiw));
					//ROS_INFO("%d",(i-1) *  height+ j-1- zhangaiw);
					nn.push_back(float(1));
					net1.push_back(nn);
					nn.clear();
					//std::cout << "(" << i << "," << j -1<< ") " << i * 40 + j - 1 - zhangaiw << std::endl;
				}
				else
				{

				}
				cost=static_cast<int>(costmap_->getCost(i-1, j-1));
				if ((i - 1) >= 0 && (j - 1) >= 0 &&cost==0 )
				{
					for (int a = 0; a < zhangaiw1.size(); a++)
					{
						if (int(zhangaiw1[a][0]) == (i - 1) && int(zhangaiw1[a][1] )== (j - 1))
						{
							zhangaiw = int(zhangaiw1[a][2]);
							break;
						}
					}
					nn.push_back(float(rongqi));
					nn.push_back(float((i - 1) * height+ j - 1 - zhangaiw));
					//ROS_INFO("%d",(i-1) * width + j -1- zhangaiw);
					nn.push_back(float(sqrt(2)));
					net1.push_back(nn);
					nn.clear();
					//std::cout << "(" << i - 1 << "," << j - 1 << ") " << (i - 1) * 40 + j - 1 - zhangaiw << std::endl;
				}
				else
				{

				}
				cost=static_cast<int>(costmap_->getCost(i-1, j-1));
				if ((i + 1) < width && (j - 1) > 0 && cost==0)
				{
					for (int a = 0; a < zhangaiw1.size(); a++)
					{
						if (int(zhangaiw1[a][0]) == (i + 1) && int(zhangaiw1[a][1] )== (j - 1))
						{
							zhangaiw = int(zhangaiw1[a][2]);
							break;
						}
					}
					nn.push_back(float(rongqi));
					nn.push_back(float((i + 1) * height+ j - 1 - zhangaiw));
					nn.push_back(float(sqrt(2)));
					net1.push_back(nn);
					nn.clear();
					//std::cout << "(" << i + 1 << "," << j - 1 << ") " << (i + 1) * 40 + j - 1 - zhangaiw << std::endl;
				}
				cost= static_cast<int>(costmap_->getCost(i-1, j+1));
				if ((i - 1) >= 0 && (j + 1) < height && cost==0 )
				{
					for (int a = 0; a < zhangaiw1.size(); a++)
					{
						if (int(zhangaiw1[a][0]) == (i - 1) &&int(zhangaiw1[a][1] )== (j + 1))
						{
							zhangaiw = int(zhangaiw1[a][2]);
							break;
						}
					}
					nn.push_back(float(rongqi));
					nn.push_back(float((i - 1) * height + j + 1 - zhangaiw));
					nn.push_back(float(sqrt(2)));
					net1.push_back(nn);
					nn.clear();
					//std::cout << "(" << i - 1 << "," << j + 1 << ") " << (i - 1) * 40 + j + 1 - zhangaiw << std::endl;
				}
				cost= static_cast<int>(costmap_->getCost(i+1, j+1));
				if ((i + 1) < width && (j + 1) < height &&cost==0)
				{
					for (int a = 0; a < zhangaiw1.size(); a++)
					{
						if (int(zhangaiw1[a][0]) == (i + 1) && int(zhangaiw1[a][1] )== (j + 1))
						{
							zhangaiw = int(zhangaiw1[a][2]);
							break;
						}
					}
					nn.push_back(float(rongqi));
					nn.push_back(float((i + 1) * height + j + 1 - zhangaiw));
					//ROS_INFO("%d",(i+1) * width + j+1 - zhangaiw);
					nn.push_back(float(sqrt(2)));
					net1.push_back(nn);
					nn.clear();
					//std::cout << "(" << i + 1 << "," << j + 1 << ") " << (i + 1) * 40 + j + 1 - zhangaiw << std::endl;
				}
				rongqi++;
	//ROS_INFO("d2 %d",i);
			}


			

			//std::cout << "--------------------------------------------" << std::endl;

		}
	
		
	}
            resolution = costmap_->getResolution();
            find_zero();
            //pdist();
	        Net_init();
	      init_op(lb, ub);
          ROS_INFO("ACO planner initialized successfully");
          iinit = true;
         }
         else{
              ROS_WARN("This planner has already been initialized... doing nothing");
         }

     }

   bool GA::makePlan(const geometry_msgs::PoseStamped &start, const geometry_msgs::PoseStamped &goal,std::vector<geometry_msgs::PoseStamped> &plan)
    {
        int numAgent1=20;
	int maxIteration1=10;
	float p1_g=0.8;
	float bianyi=0.2;
	float FA_gama=1;
    // ROS_INFO("1");
          if (!iinit)
        {
            ROS_ERROR("The planner has not been initialized, please call initialize() to use the planner");
            return false;
        } 

if (goal.header.frame_id != costmap_ros_->getGlobalFrameID())
        {
            ROS_ERROR("This planner as configured will only accept goals in the %s frame, but a goal was sent in the %s frame.",
                costmap_ros_->getGlobalFrameID().c_str(), goal.header.frame_id.c_str());
            return false;
        }  

    tf::Stamped<tf::Pose> goal_tf;
    tf::Stamped<tf::Pose> start_tf;
 resut.fit.clear();
				 plan.clear();
			
               resut.path0.clear();
			   resut.path1.clear();
			   resut.path2.clear();
			   optio.x.clear();
    poseStampedMsgToTF(goal, goal_tf);
    poseStampedMsgToTF(start, start_tf);
     float startX = start.pose.position.x;
    float startY = start.pose.position.y;
//ROS_INFO("stary=%.2f",startY);
        float goalX = goal.pose.position.x;
        float goalY = goal.pose.position.y;
        //ROS_INFO("goaly=%.2f",goalY);

        getCorrdinate(startX, startY);   //获取起点在世界坐标系下的坐标
        getCorrdinate(goalX, goalY);     
    //ROS_INFO("goaly=%.2f",goalY);
SAE_init(startX, startY, goalX, goalY);
//ROS_INFO("2");
if(int(my_A.noS)!=int(my_A.noE))
    {
		
	//ROS_INFO("10");
	init_IF(numAgent1, maxIteration1, p1_g, bianyi, FA_gama);
	ROS_INFO("1111");
	GA1();
	if(resut.path1.size()!=0)
	{
	for (int i = 0; i < resut.path1.size(); i++)
	{
					float x = 0.0;
                    float y = 0.0;

                    

                    geometry_msgs::PoseStamped pose = goal;

                    pose.pose.position.x = my_A.node[int(resut.path1[i])][0]*  resolution +originX;
                    pose.pose.position.y = my_A.node[int(resut.path1[i])][1]*resolution+originY;
                    pose.pose.position.z = 0.0;

                    pose.pose.orientation.x = 0.0;
                    pose.pose.orientation.y = 0.0;
                    pose.pose.orientation.z = 0.0;
                    pose.pose.orientation.w = 1.0;

                    plan.push_back(pose);

		//std::cout << "("<<my_A.node[resut.path1[i]][0] << ","<<my_A.node[resut.path1[i]][1]<<")"<<std::endl;
	}
	//  float path_length = 0.0;
    //             std::vector<geometry_msgs::PoseStamped>::iterator it = plan.begin();    
    //             geometry_msgs::PoseStamped last_pose;
    //             last_pose = *it;
    //             it++;
    //            // ROS_INFO("6");
    //             for (; it != plan.end(); ++it)
    //             {
    //                 path_length += hypot((*it).pose.position.x - last_pose.pose.position.x,
    //                                     (*it).pose.position.y - last_pose.pose.position.y);
    //                 last_pose = *it;
    //             }           
    //             std::cout << "The global path length: " << path_length << " meters" << std::endl;
	   nav_msgs::Path path;
	     path.poses.resize(plan.size());  
	   if (plan.empty())
                {
                    //still set a valid frame so visualization won't hit transform issues
                    path.header.frame_id = _frame_id;
                    path.header.stamp = ros::Time::now();
                }
                else
                {
                    path.header.frame_id = plan[0].header.frame_id;
                    path.header.stamp = plan[0].header.stamp;
                }           

                // Extract the plan in world co-ordinates, we assume the path is all in the same frame
                for (int i = 0; i < plan.size(); i++)
                {
                    path.poses[i] = plan[i];
                }
				    for (int i = 0; i < plan.size(); i++)
                {
                    path.poses[i] = plan[i];
                }
      ROS_INFO("7");
                _plan_pub.publish(path);
			   ROS_INFO("The planner find a path......, ");

                return true;
	}
	  else
            {
                ROS_WARN("The planner failed to find a path, choose other goal position");
               
                return false;
            }
	}
	else{
		 ROS_WARN("Not valid start or goal");
             
            return false;
	}
    }
     void GA::getCorrdinate(float &x, float &y)
    {//ROS_INFO("8");
        x = x - originX;
        y = y - originY;
    }

     void GA::find_zero()//判断非障碍
{
	// std::vector<float> x;
	
	
	// for (int i = 0; i < my_A.map.size(); i++)
	// {
	// 	for (int j = 0; j < my_A.map[i].size(); j++)
	// 	{
	// 		if (my_A.map[i][j] == 0)
	// 		{
	// 			x.push_back(float(i));
	// 			x.push_back(float(j));
	// 			//std::cout << i << "," << j << " ";
	// 			my_A.landmak.push_back(x);
	// 		}
	// 		//std::cout << std::endl;
			
	// 		x.clear();

	// 	}
	// }
	my_A.node = zhangaiw1;
	//std::cout << my_A.landmak.size();
}
void GA::pdist()
{
	std::vector<float> distance;
	//distance.clear();
	//std::cout << distance[0] << std::endl;
	//distance.push_back(1);

	std::vector<std::vector<float>>node1(my_A.node);
	
	for (int idi = 0; idi < my_A.node.size(); idi++)
	{
		//std::cout << my_A.node[idi].size()<<std::endl;
		int x = my_A.node[idi][0];
		int y = my_A.node[idi][1];
		//std::cout << x;
		for (int idj = 0; idj < node1.size(); idj++)
		{
			
			int x1= node1[idj][0];
			int y1 = node1[idj][1];
			//std::cout << x << " " << x1;
			float dist = sqrt(pow(x - x1, 2) + pow(y - y1, 2));
			//std::cout << dist<<" ";
			distance.push_back(dist);
			//std::cout << distance[idj] << std::endl;
			//std::cout << sqrt(pow(x - x1, 2) + pow(y - y1, 2));
		}
		my_A.D.push_back(distance);
		distance.clear();
	}
}
void GA::Net_init()
{
	// std::vector<float>p;
	// float r = sqrt(2);
	// for (int x = 0; x < my_A.D.size(); x++)
	// {
	// 	for (int y = 0; y < my_A.D[x].size(); y++)
	// 	{
	// 		if (my_A.D[x][y] <= r)
	// 		{
	// 			p.push_back(x);
	// 			p.push_back(y);
	// 			p.push_back(my_A.D[x][y]);
	// 			my_A.net.push_back(p);

	// 		}
	// 		p.clear();

	// 	}
	// }
	// p.push_back(my_A.node.size() - 1);
	// p.push_back(my_A.node.size() - 1);
	// p.push_back(my_A.D[my_A.node.size() - 1][my_A.node.size() - 1]);
	my_A.net=net1;
}
void GA::SAE_init(float S_x, float S_y, float E_x, float E_y)
{
	//ROS_INFO("3")
	my_A.start_x = S_x/ resolution;
	//ROS_INFO("3%d",int(my_A.start_x));
	my_A.start_y = S_y/ resolution;
	my_A.end_x = E_x /resolution;
	my_A.end_y = E_y/ resolution;
	//ROS_INFO("(%f,%f),(%f,%f)",my_A.start_x,my_A.start_y,my_A.end_x,my_A.end_y  );
	for (int i = 0; i < my_A.node.size(); i++)
	{
		if (my_A.node[i][0] == int(my_A.start_x )&& my_A.node[i][1]==int(my_A.start_y) )
		{
			my_A.noS =float(i);

			ROS_INFO("no s%d",i);
		}
		else{
			
		}
		if (my_A.node[i][0] == int(	my_A.end_x) && my_A.node[i][1]==int(my_A.end_y) )
		{
			my_A.noE =float (i);
			//std::cout << i;
			ROS_INFO("no E,%d",i);
		}
		else{

		}
	}
}
void GA::init_op(float lb, float ub)
{
	optio.lb.push_back(lb);
	optio.ub.push_back(ub);
	optio.dim = my_A.net.size();
	//ROS_INFO("size%d",my_A.net.size());
	if (optio.lb.size() == 1)
	{
		optio.lb.resize(optio.dim, lb);
		optio.ub.resize(optio.dim, ub);
	}

}
void GA::aimFcn_1()
{
	//std::cout << my_A.noE <<" "<< my_A.noS;
//ROS_INFO("4");
	float alpha = 1;
	std::vector<float> D1, D2, pri;
	float punishiment = 0;
	float beta = 1;
	//suiji=100000.0;
	float s = my_A.noS;
	float P[2];
	float fit;
	std::vector<int> flag;
	int nextnode;
	flag.resize(my_A.net.size(), 0);
	std::vector<float> path;
	std::vector<int>position;
	std::vector<float>temp;
	path.push_back(s);
	float D=0;
	flag[int(s)] = 1;
	int kk = 0;
	//ROS_INFO("14");
	while (s!=my_A.noE)
	{
	//	ROS_INFO("154");
		for (int i = 0; i < my_A.net.size(); i++)
		{
			if(my_A.net[i][1]==s && flag[i] == 0)
			{
				//std::cout << flag[i];
				
					position.push_back(i);
				
			}
		}
		//ROS_INFO("155posaize%d",position.size());
		if (position.size() == 0)
		{
			break;
		}
		
		D1.resize(position.size(), 0);
		D2.resize(position.size(), 0);
		pri.resize(position.size(), 0);
		//ROS_INFO("netsize%d,nodesize%d",my_A.net.size(),my_A.node.size());
		for (int i = 0; i < position.size(); i++)
		{
			//ROS_INFO("pose%d,",int(position[i]));
			nextnode = my_A.net[position[i]][0];
			//ROS_INFO("next%d",int(nextnode));
			P[0] = my_A.node[nextnode][0];
			//ROS_INFO("p=%f",P[0]);
		
			P[1]= my_A.node[nextnode][1];
			//ROS_INFO("p1=%f",P[1]);
			D2[i] = float(sqrt(pow(P[0] - my_A.end_x, 2) + pow(P[1] - my_A.end_y, 2)));
			D1[i] = my_A.net[position[i]][2];
			pri[i] = optio.x[x_indx][position[i]];
			//ROS_INFO("node%d,",nextnode);

		}
		//ROS_INFO("1111334");
		for (int i = 0; i < pri.size(); i++)
		{
			temp.push_back(float(pow(pri[i], alpha) / pow(D2[i] +pow( D1[i],3), beta)));
		//	ROS_INFO("temp=%f",float(pow(pri[i], alpha) / pow(pow(D[]) + D1[i], beta)));

		}
		int maxPosition = max_element(temp.begin(), temp.end()) - temp.begin();
//OS_INFO("max=%d",maxPosition);
		//std::cROS_INFOout << maxPosition<<" ";
		int post = position[maxPosition];
		s = my_A.net[post][0];
		flag[post] = 1;
		//ROS_INFO("41:%d",post);
		if (s != path[path.size()-1])

		{
			path.push_back(s);
			
			float d1 = my_A.net[post][2];
			D = D + d1;
			if (biaozhi == 0)
			{
				if (suiji < D)
				{
					break;
				}
			}
			// else  if(biaozhi==1)
			// {
			// 	if(suiji<D)
			// 	 {
			// 		break;
			// 	}
			// }
			//ROS_INFO("x=%.2f,y=%.2f",my_A.node[s][0],my_A.node[s][1]);
		//	kk++;
		}
		
		
		
		D1.clear();
		 D2.clear();
		  pri.clear();
		temp.clear();
		position.clear();
	}
	if (s == my_A.noE)
	{
		punishiment = float(sqrt(pow(my_A.node[int(my_A.noS)][0] - my_A.node[int(my_A.noE)][0], 2) + pow(my_A.node[int(my_A.noS)][1] - my_A.node[int(my_A.noE)][1], 2)));
		fit = D + punishiment;
ROS_INFO("fit=%.2f,indx=%d",fit,x_indx);


		resut.fit1 = fit;
		
		//std::cout << fit << std::endl;
		if (resut.fit.size() <optio.numAgent)
		{
			resut.fit.push_back(fit);
		}
		else
		{
			resut.fit[x_indx] = fit;
		}
		resut.path0.push_back(path);
		resut.path1 = path;
		resut.path2 = path;
	}
	else {

		resut.fit1 = 10000000;
		//std::cout << fit << std::endl;
		if (resut.fit.size() <optio.numAgent )
		{
			resut.fit.push_back(100000);
		}
		else
		{
			resut.fit[x_indx] = float(100000);
		}
		if(biaozhi==0)
		{resut.path0.push_back(path);
		resut.path1 = path;
		resut.path2 = path;
	}
//	ROS_INFO("fit=%f",resut.fit[x_indx] );
	}

}
void GA::init_IF(int numAgent1, int maxIteration1, float FA_alpha, float FA_beta0, float FA_gama)
{
	srand(time(0));
	x_indx = 0;
	biaozhi=1;
	std::vector<float> ran;
	optio.numAgent = numAgent1;
	optio.maxIteration = maxIteration1;
	optio.FA_alpha = FA_alpha;
	optio.FA_beta0 = FA_beta0;
	optio.FA_gama = FA_gama;
	optio.lb.resize(optio.dim, 0);
	optio.ub.resize(optio.dim, 1);
//	suiji=1000001.0;
	for (int i = 0; i < optio.numAgent; i++)
	{
	
		for (int j = 0; j < optio.lb.size(); j++)
		{
			float k = (float(rand() % 100 )/ (float)(100)) * (optio.ub[j] - optio.lb[j]) + optio.lb[j];
			//ROS_INFO("k=%f",k);
			ran.push_back(k);
			//std::cout <<"k:"<< k << " ";

		}
		//ROS_INFO("I=%d",i);
		optio.x.push_back(ran);
		
		aimFcn_1();
		x_indx++;
		ran.clear();

	}

	biaozhi=0;

}
void GA::GA1()
{
	float p1_g =	optio.FA_alpha ;
	float p2_g = optio.FA_beta0;
	biaozhi = 0;
	float y_g;
	float mean=0;
	int maxContest;
	int index;
	float rand2;
	float rand1;
	int minPosition;
	std::vector<float> x_g;
	std::vector<float> y_p;
	std::vector<float>newY;
	std::vector<float> post;
	std::vector<int>indxx;
	std::vector<int>parent;
	std::vector<float>tempR;
	std::vector<float>temp;
	int minP;
	std::vector<std::vector<float>>newX;
	srand((unsigned)time(NULL));
	std::vector<std::vector<float>> x_p;
	//recode.bestFit.resize(optio.maxIteration+1, 1);
	//recode.meanFit.resize(optio.maxIteration+1, 1);
	minPosition = min_element(resut.fit.begin(), resut.fit.end()) - resut.fit.begin();
	y_g = resut.fit[minPosition];
	
	//std::cout<< "最小fit"<<resut.fit[minPosition]<<" ";
	x_g = optio.x[minPosition];
	y_p = resut.fit;
	//recode.bestFit[0] = y_g;
	for (int inter = 0; inter < resut.fit.size(); inter++)
	{
		mean = mean + resut.fit[inter];

	}
	mean = mean / float(resut.fit.size());
	//recode.meanFit[0] = mean;
	for (int iter = 0; iter < optio.maxIteration; iter++)
	{
		for (int ji = 0; ji < optio.numAgent * 2; ji++)
		{
			maxContest = rand() % optio.numAgent;
			if (maxContest == 0)
			{
				maxContest = 3;
			}
			for (int k = 0; k < maxContest; k++)
			{
				index=rand()% (optio.numAgent);
				
				//std::cout << resut.fit[index] << " ";
				post.push_back(resut.fit[index]);
				indxx.push_back(index);
			}
			minP = min_element(post.begin(), post.end()) - post.begin();
			//std::cout << indxx.size() << " ";
			//std::cout << indxx.size()<<" "<< indxx[minP] << " " <<std::endl;
			parent.push_back(indxx[minP]);
			post.clear();
			indxx.clear();
		}
		//交叉
		for (int i = 0; i < optio.numAgent; i++)
		{
			newX.push_back(optio.x[parent[i]]);
			if (float(rand() % 101) / float(100) < p1_g)
			{
				for (int ran = 0; ran < optio.x[i].size(); ran++)
				{
					rand1 = float(rand() % 1001) / float(1000);
					tempR.push_back(rand1);
					if (rand1 > 0.5)
					{
						newX[i][ran] = optio.x[parent[i + optio.numAgent]][ran];
					}

				}

			}
		}
		//变异
		tempR.clear();

		for (int by = 0; by < optio.numAgent * p2_g; by++)
		{
			index = rand() % optio.numAgent;
			for (int ran = 0; ran < optio.x[by].size(); ran++)
			{
				rand1 = float(rand() % 1001) / float(1000);
				tempR.push_back(rand1);
				rand2 = (float(rand() % 1001) / float(1000))*(optio.ub[ran]-optio.lb[ran])*optio.ub[ran];
				temp.push_back(rand2);
				

			}
			for (int k = 0; k < optio.x[by].size(); k++)
			{
				if (tempR[k] > 0.5)
				{
					int rr = rand() % temp.size();
					for (int ll = rr; ll < temp.size(); ll++)
					{
						if (temp[ll] > 0.5)
						{
							newX[by][k] = temp[ll];
							break;
						}
					}
				}
			}

		}
		//重新计算适应度值
		for (int ji=0;ji<optio.numAgent;ji++)
		{
			x_indx = ji;
			optio.x[x_indx] = newX[ji];
			
			aimFcn_1();
			if (resut.fit[ji] < y_p[ji])
			{
				y_p[ji] = resut.fit[ji];
				x_p.push_back( newX[ji]);
				if (y_p[ji] < y_g)
				{
					y_g = y_p[ji];
					//std::cout << y_g << " "<<std::endl;
					x_g = x_p[x_p.size()-1];
				}
			}
			

		}
		newX.clear();
		x_p.clear();
		resut.path0.clear();
		resut.path1.clear();
		resut.path2.clear();
		

	}
	
	x_indx = 0;
	optio.x[x_indx] = x_g;
	aimFcn_1();
	// for (int i = 0; i < resut.path1.size(); i++)
	// {
	// 	std::cout << "(" << my_A.node[resut.path1[i]][0] << "," << my_A.node[resut.path1[i]][1] << ")" << std::endl;
	// }
}

};
