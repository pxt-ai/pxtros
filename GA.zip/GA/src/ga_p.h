#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 
#include <string>

/** include the libraries you need in your planner here */
#include <ros/ros.h>

#include <actionlib/client/simple_action_client.h>
#include <move_base_msgs/MoveBaseAction.h>

#include <geometry_msgs/Twist.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <move_base_msgs/MoveBaseGoal.h>
#include <move_base_msgs/MoveBaseActionGoal.h>

#include "sensor_msgs/LaserScan.h"
#include "sensor_msgs/PointCloud2.h"

#include <nav_msgs/Odometry.h>
#include <nav_msgs/OccupancyGrid.h>
#include <nav_msgs/Path.h>
#include <nav_msgs/GetPlan.h>

#include <tf/tf.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_listener.h>

#include <boost/foreach.hpp>
//#define forEach BOOST_FOREACH

/** for global path planner interface */
#include <costmap_2d/costmap_2d_ros.h>
#include <costmap_2d/costmap_2d.h>
#include <nav_core/base_global_planner.h>

#include <geometry_msgs/PoseStamped.h>
#include <angles/angles.h>

//#include <pcl_conversions/pcl_conversions.h>
#include <base_local_planner/world_model.h>
#include <base_local_planner/costmap_model.h>
#include<algorithm>

#include <set>
#ifndef  GA_P_H
#define GA_P_H
namespace GA_planner
{
    class GA:public nav_core::BaseGlobalPlanner
    {

public:
	
	GA();
	
		//my_A.node = my_A.landmak;

	
    GA(ros::NodeHandle &);
    GA(std::string name, costmap_2d::Costmap2DROS* costmap_ros);

	~GA()
	{

	}
    bool iinit;
	int biaozhi;
	int width,height;
 std::vector<float> z;
	std::vector<std::vector<float>>zhangaiw1;
	std::vector<std::vector<float>> net1;
    ros::NodeHandle ROSNodeHandle;
    ros::Publisher _plan_pub;
    std::string _frame_id;
    float originX;
    float originY;
     float resolution;
	float suiji;
     costmap_2d::Costmap2DROS* costmap_ros_;
            //double step_size_, min_dist_from_robot_;
    costmap_2d::Costmap2D* costmap_;
    void initialize(std::string name, costmap_2d::Costmap2DROS* costmap_ros);
    bool makePlan(const geometry_msgs::PoseStamped& start, const geometry_msgs::PoseStamped& goal,  std::vector<geometry_msgs::PoseStamped>& plan );
	int x_indx;
	struct my_afo
	{
		float start_x;
		float start_y;
		float end_x;
		float end_y;
		std::vector<std::vector<float>> landmak;
		std::vector<std::vector<float>>  node;
		std::vector<std::vector<float>> D;
		std::vector<std::vector<float>> net;
		float noS, noE;
		std::vector<std::vector<unsigned int>> map;



	};
	struct restult
	{
		float fit1;
		std::vector<float> fit;
		std::vector<float> path1, path2;
		std::vector<std::vector<float>>path0;
	};
	struct option
	{
		float fobj, fit, result, x0, FA_alpha, FA_beta0, FA_gama;
		std::vector<std::vector<float>> x;
		std::vector<float> y;
		std::vector<float>lb,ub;
		int dim;
		int numAgent, maxIteration;
	};
	struct recording
	{
		std::vector<float>bestFit, meanFit;
	};
	my_afo my_A;
	void find_zero();
	void pdist();
	void Net_init();
	void SAE_init(float S_x, float S_y, float E_x, float E_y);
	option optio;
	void init_op(float lb,float ub);
	void aimFcn_1();
	void init_IF(int numAgent1, int maxIteration1, float FA_alpha, float FA_beta0, float FA_gama);
	void GA1();
     void getCorrdinate (float& x, float& y); 
	restult resut;
	recording recode;
        
    };

};

#endif