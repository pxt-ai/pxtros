#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <string>
#include <cmath>
#include <time.h>
#include <random>
#include <vector>
#include "GA_planner_j.h"
#include<algorithm>
#include <numeric>

#include <pluginlib/class_list_macros.h>
PLUGINLIB_EXPORT_CLASS(GA_planne_j::GA_P, nav_core::BaseGlobalPlanner)
namespace GA_planne_j
{
    GA_P::GA_P()
    {

    }
    GA_P::GA_P(ros::NodeHandle &nh)
    {
         ROSNodeHandle = nh;
    }
     GA_P::GA_P(std::string name, costmap_2d::Costmap2DROS* costmap_ros)
     {
		 ROS_INFO("1");
           initialize(name,  costmap_ros);
     }
      void GA_P::initialize(std::string name, costmap_2d::Costmap2DROS* costmap_ros)
      {
		  ROS_INFO("2");
          std::vector<int>ma;
            int cost;
            globfit = 100000;
			pointNum = 7;
			alpha = 1;
			glaob.fintess = 1000000;
			p_select=0.5;
			p_crs = 0.8;
			p_mut=0.8;
			N=100;
			M=50;
             iinit=false;
              if(!iinit)
         {

		   costmap_ros_ = costmap_ros;
            costmap_ = costmap_ros_->getCostmap();

            ros::NodeHandle private_nh("~/" + name);
            _plan_pub = private_nh.advertise<nav_msgs::Path>("global_plan", 1);
            _frame_id = costmap_ros->getGlobalFrameID();
             originX = costmap_->getOriginX();
            originY = costmap_->getOriginY();
			width = costmap_->getSizeInCellsX();
            height = costmap_->getSizeInCellsY();
            
			ROS_INFO("width:%d,heeight:%d",width,height);
			
            for ( int ix= 0; ix < width; ix++)
            {
                for (int iy= 0; iy< height; iy++)
                {
                      cost = static_cast<int>(costmap_->getCost(ix, iy));
                      if(cost>0)
                      {
                          cost=1;
                      }
                  //  x.push_back(cost);
                  ma.push_back(cost);
				
                }
                map.push_back(ma);
                ma.clear();
                
            }	
			 resolution = costmap_->getResolution();
			 ROS_INFO("ACO planner initialized successfully");
          iinit = true;
    }
       else{
              ROS_WARN("This planner has already been initialized... doing nothing");
         }
      }
       bool GA_P::makePlan(const geometry_msgs::PoseStamped& start, const geometry_msgs::PoseStamped& goal,  std::vector<geometry_msgs::PoseStamped>& plan )
       {
            if (!iinit)
        {
            ROS_ERROR("The planner has not been initialized, please call initialize() to use the planner");
            return false;
        } 
        if (goal.header.frame_id != costmap_ros_->getGlobalFrameID())
        {
            ROS_ERROR("This planner as configured will only accept goals in the %s frame, but a goal was sent in the %s frame.",
                costmap_ros_->getGlobalFrameID().c_str(), goal.header.frame_id.c_str());
            return false;
        }  
         tf::Stamped<tf::Pose> goal_tf;
    tf::Stamped<tf::Pose> start_tf;
    poseStampedMsgToTF(goal, goal_tf);
    poseStampedMsgToTF(start, start_tf);
     float startX = start.pose.position.x;
    float startY = start.pose.position.y;
//ROS_INFO("stary=%.2f",startY);
        float goalX = goal.pose.position.x;
        float goalY = goal.pose.position.y;
        //ROS_INFO("goaly=%.2f",goalY);
        getCorrdinate(startX, startY);   //获取起点在世界坐标系下的坐标
        getCorrdinate(goalX, goalY);  
		ROS_INFO("s=%.2f,%.2f,g=%.2f,%.2f",startX,startY,goalX,goalY);
		//int kx=abs(int (startX/resolution/100)-int((goalX/resolution)/100));
		int ky=abs(int(startY/resolution/100)-int(goalY/resolution/100));
        if(startX!=goalX&&startY!=goalY)
       {
           index = 1;

           for (int k = 0; k < M; k++)
	        {
		        init(startX, startY, goalX, goalY);
		        calFitness();
	        }
            index = 0;
			ROS_INFO("1");
            posinit();
       
    if(glaob.path.size()!=0)
    {
        for (int i = 0; i < glaob.path[0].size(); i++)
	{
					float x = 0.0;
                    float y = 0.0;

                    

                    geometry_msgs::PoseStamped pose = goal;

                    pose.pose.position.x =glaob.path[0][i]*  resolution +originX;
                    pose.pose.position.y = glaob.path[1][i]*resolution+originY;
                    pose.pose.position.z = 0.0;

                    pose.pose.orientation.x = 0.0;
                    pose.pose.orientation.y = 0.0;
                    pose.pose.orientation.z = 0.0;
                    pose.pose.orientation.w = 1.0;

                    plan.push_back(pose);

		//std::cout << "("<<my_A.node[resut.path1[i]][0] << ","<<my_A.node[resut.path1[i]][1]<<")"<<std::endl;
	}
         nav_msgs::Path path;
	     path.poses.resize(plan.size());  
          if (plan.empty())
                {
                    //still set a valid frame so visualization won't hit transform issues
                    path.header.frame_id = _frame_id;
                    path.header.stamp = ros::Time::now();
                }
                else
                {
                    path.header.frame_id = plan[0].header.frame_id;
                    path.header.stamp = plan[0].header.stamp;
                }       
                     for (int i = 0; i < plan.size(); i++)
                {
                    path.poses[i] = plan[i];
                }
				    for (int i = 0; i < plan.size(); i++)
                {
                    path.poses[i] = plan[i];
                }
      ROS_INFO("7");
                _plan_pub.publish(path);
			   ROS_INFO("The planner find a path......, ");
			  
partic.pos1.x.clear();
	partic.path.clear();
	partic.v1.x.clear();
	partic.v1.y.clear();
	partic.pos1.x.clear(); partic.best.pos2.x.clear();
	partic.pos1.y.clear(); partic.best.pos2.y.clear();
	partic.best.path.clear();

	glaob.path.clear();
	glaob.poss.x.clear();
	glaob.poss.y.clear();
	glaob.fintess=100000.0;
	par.clear();
	//path.poses.clear();
    return true;

    }
    else{
        ROS_WARN("The planner failed to find a path, choose other goal position");
               partic.pos1.x.clear();
	partic.path.clear();
	partic.v1.x.clear();
	partic.v1.y.clear();
	partic.pos1.x.clear(); partic.best.pos2.x.clear();
	partic.pos1.y.clear(); partic.best.pos2.y.clear();
	partic.best.path.clear();

	glaob.path.clear();
	glaob.poss.x.clear();
	glaob.poss.y.clear();
	glaob.fintess=100000.0;
	par.clear();
                return false;
    }

       } 
       else
       {
           ROS_WARN("Not valid start or goal");
             partic.pos1.x.clear();
	partic.path.clear();
	partic.v1.x.clear();
	partic.v1.y.clear();
	partic.pos1.x.clear(); partic.best.pos2.x.clear();
	partic.pos1.y.clear(); partic.best.pos2.y.clear();
	partic.best.path.clear();

	glaob.path.clear();
	glaob.poss.x.clear();
	glaob.poss.y.clear();
	glaob.fintess=100000.0;
	par.clear();
            return false;
       }
       }
       void GA_P::getCorrdinate (float& x, float& y)
     {
         x = x - originX;
        y = y - originY;
     }
       void GA_P::init(float s_x,float s_y,float e_x,float e_y)
{
	//srand((unsigned int)time(NULL));
	float ran1;
	float ran2;
	start_x = s_x/ resolution;
	start_y = s_y/ resolution;
	end_x = e_x/ resolution;
	end_y=e_y/ resolution;
	for (int k = 0; k < pointNum; k++)
	{
	//	ROS_INFO("1");
		if (int(end_x - start_x) >=0 && int(end_y - start_y) >= 0)
		{
			if (k == 0)
			{
				if(int(end_x- start_x)==0)
				{
					ran1=start_x;
				}
			else{
ran1 = float(rand() % (int(end_x- start_x)) + int(start_x));
			}
				
				//ROS_INFO("ran1%.2f",ran1);
				if(int(end_y - start_y)==0)
				{
					ran2=end_y;
				}
				else
				{
ran2 = float(rand() % (int(end_y - start_y)) + int(start_y));
				}
				
				//ROS_INFO("ran2%.2f",ran2);
			}
			else {
				if(int(end_x- partic.pos1.x[k - 1])== 0)
				{
					ran1 = float(rand() % (int(end_x- partic.pos1.x[k - 1])+1) + int(partic.pos1.x[k - 1]));
					//ROS_INFO("ran3%.2f",ran1);
				}
				else{
					ran1 = float(rand() % (int(end_x- partic.pos1.x[k - 1])) + int(partic.pos1.x[k - 1]));
					//ROS_INFO("ran4%.2f",ran1);
				}
				if(int(end_y - partic.pos1.y[k - 1])== 0)
				{
					ran2 = float(rand() % (int(end_y - partic.pos1.y[k - 1])+1) + int(partic.pos1.y[k - 1]));
					//ROS_INFO("ran5%.2f",ran2);
				}
				else
				{
						ran2 = float(rand() % (int(end_y - partic.pos1.y[k - 1])) + int(partic.pos1.y[k - 1]));
						//ROS_INFO("ran5%.2f",ran2);
				}
				
				
			}
			while (map[int(ran1)][int(ran2)] == 1)
			{
				ran1 = float(rand() % (int(end_x - start_x)) + int(start_x));
				ran2 = float(rand() % (int(end_y - start_y)) + int(start_y));
			}
		}
		else if (int(end_x - start_x) <= 0 && int(end_y - start_y) <= 0)
		{
			//ROS_INFO("2");
			if (k == 0)
			{
				if(int( start_x-end_x)==0)
				{
					ran1=start_x;
				}
				else
				{
					ran1 = float(rand() % (int( start_x-end_x)) + int(end_x));
				}
				if(int(start_y - end_y)==0)
				{
					ran2=start_y;
				}
				else{
ran2 = float(rand() % (int(start_y - end_y)) + int(end_y));
				}
				
			}
			else {
				//std::cout << partic.pos1.x[k - 1] - end_x+end_x<<" ";
				//ran1 = 0;
				//ran2 = 0;
				if(int(partic.pos1.x[k - 1]-end_x)==0)
				{
				ran1 = float(rand() % (int(partic.pos1.x[k - 1]-end_x)+1 ) + end_x);
				}
				else
				{
						ran1 = float(rand() % (int(partic.pos1.x[k - 1]-end_x )) + end_x);
				}
				if(int(partic.pos1.y[k - 1]-end_y )==0)
				{
				ran2 = float(rand() % (int(partic.pos1.y[k - 1]-end_y )+1) + end_y);
				}
				else
				{
					ran2 = float(rand() % (int(partic.pos1.y[k - 1]-end_y )) + end_y);
				}
			}
			while (map[int(ran1)][int(ran2)] == 1)
			{
				ran1 = float(rand() % (int(start_x - end_x)+1) + int(end_x));
				ran2 = float(rand() % (int(start_y - end_y)+1) + int(end_y));
			}

		}
		else if ((end_x - start_x) >= 0 && (end_y - start_y) <= 0) 
		{
			//ROS_INFO("3");
			if(k == 0)
			{
				if(int( start_x-end_x)==0)
				{
					ran1=start_x;
				}
				else
				{
						ran1 = float(rand() % (int(end_x - start_x)) + int(start_x));
				}
				if(int(start_y - end_y)==0)
				{
					ran2=start_y;
				}
				else{
					ran2 = float(rand() % (int(start_y - end_y)) + int(end_y));
				}
				
				
			}
		else {
			if(int(end_x - partic.pos1.x[k - 1])==0)
			{
			ran1 = float(rand() % (int(end_x - partic.pos1.x[k - 1])+1) + int(partic.pos1.x[k - 1]));
			}
			else
			{
				ran1 = float(rand() % (int(end_x - partic.pos1.x[k - 1])) + int(partic.pos1.x[k - 1]));
			}
			if(int(partic.pos1.y[k - 1] - end_y)==0)
			{
					ran2 = float(rand() % (int(partic.pos1.y[k - 1] - end_y) + 1) + end_y);
			}
			else{
				ran2 = float(rand() % (int(partic.pos1.y[k - 1] - end_y) ) + end_y);
			}
			//ran2 = float(rand() % (int(partic.pos1.y[k - 1] - end_y) + 1) + end_y);
		}
		while (map[int(ran1)][int(ran2)] == 1)
		{
			ran1 = float(rand() % (int(end_x - start_x)) + int(start_x));
			ran2 = float(rand() % (int(start_y - end_y)) + int(end_y));
		}
		}
		else {
			//ROS_INFO("4");
			if (k == 0)
			{
				if(int( start_x-end_x)==0.0)
				{
					ran1=start_x;
				}
				else
				{
						ran1 = float(rand() % (int(start_x - end_x)) + int(end_x));
				}
				if(int(start_y - end_y)==0.0)
				{
					ran2=start_y;
				}
				else{
				ran2 = float(rand() % (int(end_y - start_y)) + int(start_y));
				}
			
			}
			else {
				if(int(partic.pos1.x[k - 1] - end_x)==0)
				{
					ran1 = float(rand() % (int(partic.pos1.x[k - 1] - end_x) + 1) + end_x);
				}
				else
				{
					ran1 = float(rand() % (int(partic.pos1.x[k - 1] - end_x) ) + end_x);
				}
				if(int(end_y - partic.pos1.y[k - 1])==0)
				{
					ran2 = float(rand() % (int(end_y - partic.pos1.y[k - 1])+1) + int(partic.pos1.y[k - 1]));
				}
				else{
					ran2 = float(rand() % (int(end_y - partic.pos1.y[k - 1])) + int(partic.pos1.y[k - 1]));
				}
				
			}
			while (map[int(ran1)][int(ran2)] == 1)
			{
				ran1 = float(rand() % (int(start_x - end_x)) + int(end_x));
				ran2 = float(rand() % (int(end_y - start_y)) + int(start_y));
			}
		}

		partic.pos1.x.push_back(ran1);
		partic.pos1.y.push_back(ran2);
		partic.v1.x.push_back(0.0);
		partic.v1.y.push_back(0.0);
	}
}
void GA_P::calFitness()
{
	int l1 = 0, l2 = 0, l3 = 0, l4 = 0;
	int x = 0, y = 0, x1 = 0, y1 = 0;
	float dist = 0;
	int biao1 = 0, biao2 = 0;
	std::vector<float>x_seq, y_seq, X_seq, Y_seq;

	x_seq.push_back(start_x);
	y_seq.push_back(start_y);
	for (int i = 0; i < partic.pos1.x.size(); i++)
	{
		x_seq.push_back(partic.pos1.x[i]);
		y_seq.push_back(partic.pos1.y[i]);
	}
	x_seq.push_back(end_x);
	y_seq.push_back(end_y);
	X_seq.push_back(start_x);
	Y_seq.push_back(start_y);
	for (int i = 1; i < x_seq.size(); i++)
	{
		//std::cout << i;
		if (abs(x_seq[i] - x_seq[i - 1]) > abs(y_seq[i] - y_seq[i - 1]))
		{
			if (x_seq[i] > x_seq[i - 1])
			{
				l1 = int(x_seq[i - 1]);
				l2 = int(x_seq[i]);
			}
			else {
				l1 = int(x_seq[i]);
				l2 = int(x_seq[i - 1]);

				biao1 = X_seq.size();

			}
			for (int k = l1; k < l2; k++)
			{
				float k1 = 0;

				//y1 + (x - x1) * (y2 - y1) / (x2 - x1);
				if ((x_seq[i] - x_seq[i - 1]) == 0)
				{
					k1 = x_seq[i];
				}
				else {
					k1 = y_seq[i - 1] + (k - x_seq[i - 1]) * (y_seq[i] - y_seq[i - 1]) / (x_seq[i] - x_seq[i - 1]);
				}
				if (y_seq[i] > y_seq[i - 1])
				{
					if (k1 > y_seq[i])
					{
						k1 = y_seq[i];
					}
					if (k1 < y_seq[i - 1])
					{
						k1 = y_seq[i - 1];
					}
				}
				else
				{
					if (k1 < y_seq[i])
					{
						k1 = y_seq[i];
					}
					if (k1 > y_seq[i - 1])
					{
						k1 = y_seq[i - 1];
					}
				}
				if (x_seq[i] > x_seq[i - 1])
				{
					Y_seq.push_back(k1);
					X_seq.push_back(float(k));
				}
				else
				{
					Y_seq.insert(Y_seq.begin() + biao1, k1);
					X_seq.insert(X_seq.begin() + biao1, float(k));
				}

				//std::cout << int(x_seq[i])<<" ,"<< k1 << std::endl;
			}
			if (x_seq[i] >= x_seq[i - 1])
			{
				X_seq.push_back(x_seq[i]);
				Y_seq.push_back(y_seq[i]);
			}

		}
		else {
			if (y_seq[i] >= y_seq[i - 1])
			{
				l3 = int(y_seq[i - 1]);
				l4 = int(y_seq[i]);
			}
			else {
				l3 = int(y_seq[i]);
				l4 = int(y_seq[i - 1]);

				biao2 = Y_seq.size();
			}
			for (int k = l3; k < l4; k++)
			{
				float k1 = 0;

				if ((y_seq[i] - y_seq[i - 1]) == 0)
				{
					k1 = y_seq[i];
				}
				else {
					k1 = x_seq[i - 1] + (k - y_seq[i - 1]) * (x_seq[i] - x_seq[i - 1]) / ((y_seq[i] - y_seq[i - 1]));
				}
				if (x_seq[i] > x_seq[i - 1])
				{
					if (k1 > x_seq[i])
					{
						k1 = x_seq[i];
					}
					if (k1 < x_seq[i - 1])
					{
						k1 = x_seq[i - 1];
					}
				}
				else
				{
					if (k1 < x_seq[i])
					{
						k1 = x_seq[i];
					}
					if (k1 > x_seq[i - 1])
					{
						k1 = x_seq[i - 1];
					}
				}
				//std::cout << k1<<" ";
				if (y_seq[i] >= y_seq[i - 1])
				{
					X_seq.push_back(k1);
					Y_seq.push_back(k);
				}
				else {
					X_seq.insert(X_seq.begin() + biao2, k1);
					Y_seq.insert(Y_seq.begin() + biao2, k);
				}
			}
			if (y_seq[i] > y_seq[i - 1])
			{
				X_seq.push_back(x_seq[i]);
				Y_seq.push_back(y_seq[i]);
			}
		}
		X_seq.push_back(x_seq[i]);
		Y_seq.push_back(y_seq[i]);
		//std::cout << "------" << std::endl;

	}
	partic.path.push_back(X_seq);
	partic.path.push_back(Y_seq);
	for (int k = 1; k < partic.path[0].size(); k++)
	{
		if (partic.path[0][k] == partic.path[0][k - 1] && partic.path[1][k] == partic.path[1][k - 1])
		{
			partic.path[0].erase(partic.path[0].begin() + k);
			partic.path[1].erase(partic.path[1].begin() + k);
			k = 1;
		}
	}
	for (int k = 0; k < partic.path[0].size(); k++)
	{
		x = partic.path[0][k];
		y = partic.path[1][k];
		//std::cout << "(" << x << "," << y << ")" << std::endl;
		if (map[int(x)][int(y)] != 0)
		{
			partic.flag = 1;
			break;
		}


	}
	for (int k = 1; k < partic.path[0].size(); k++)
	{
		x1 = partic.path[0][k - 1];
		y1 = partic.path[1][k - 1];
		x = partic.path[0][k];
		y = partic.path[1][k];
		dist = dist + sqrt(pow(x - x1, 2) + pow(y - y1, 2));

	}
	if (partic.flag == 1)
	{
		partic.fitness = dist * 100;
	}
	else
	{
		partic.fitness = dist;
	}
	if (index == 1)
	{
		//std::cout << partic.pos1.x.size() << "";
		partic.best.pos2.x = partic.pos1.x;
		partic.best.pos2.y = partic.pos1.y;
		partic.best.fitness = partic.fitness;
		partic.best.path = partic.path;
		//std::cout << glaob.fintess <<" "<< partic.fitness<<std::endl;
		if (partic.fitness < glaob.fintess)
		{
			glaob.fintess = partic.best.fitness;
			glaob.path = partic.best.path;
			glaob.poss.x = partic.pos1.x;
			//std::cout << glaob.poss.x[0];
			glaob.poss.y = partic.pos1.y;
		}
	}
	if (par.size() < M)
	{
		//partic.pos1.x.size();
		par.push_back(partic);
		//par[0].pos1.x[0];
	}
	else if (par.size() == M)
	{
		par[inters].pos1 = partic.pos1;
		par[inters].fitness = partic.fitness;
		par[inters].path = partic.path;
	}
	partic.pos1.x.clear();
	partic.path.clear();
	partic.v1.x.clear();
	partic.v1.y.clear();
	partic.pos1.x.clear();// partic.best.pos.x.clear();
	partic.pos1.y.clear(); //partic.best.pos.y.clear();



	//partic.best.path.clear();
}


void GA_P::select()
{
	float num=0.0;
	float acfit=0,rand1=0.0;
	int biaozw = 0;
	for (int i = 0; i < par.size(); i++)
	{
		num = num + par[i].fitness;
	}
	while (select_indx.size() < int(par.size() * p_select))
	{
		rand1 = float(rand() % 100 / 120.0);
		//std::cout << select_indx.size()<<" ";
		for (int pr_i = 0; pr_i < par.size(); pr_i++)
		{
			if ((rand1+ par[pr_i].fitness/num) < p_select)
			{
				//std::cout << par[pr_i].fitness / num<<" ";
				
					select_indx.push_back(pr_i);
				}
				
				if (select_indx.size() == int(par.size() * p_select))
				{
					break;
				}
			}
		}

	}

void GA_P::cross_connection()
{
	int rand1 = 0, rand2=0;
	for (int se_i = 0; se_i < select_indx.size(); se_i++)
	{
		float ran3 = float(rand() % 100 / 100.0);
		if (ran3 > (1.0 - p_crs))
		{
			rand1 = rand() % select_indx.size();
			rand2 = rand() % par[se_i].pos1.x.size();
			for (int ra = rand2; ra < par[se_i].pos1.x.size(); ra++)
			{
				par[select_indx[se_i]].pos1.x[ra] = par[select_indx[rand1]].pos1.x[ra];
				par[select_indx[se_i]].pos1.y[ra] = par[select_indx[rand1]].pos1.y[ra];
			}
			

		}
	}
	
}
void GA_P::variation()
{
	float ran1 = 0.0;
	int ran2 = 0;
	for (int se_i = 0; se_i < select_indx.size(); se_i++)
	{
		ran1 = rand() % 100 / 100.0;
		ran2=rand()% rand() % (par[se_i].pos1.x.size()-2)+1;
		if (ran1 > (1.0 - p_mut))
		{
		//	ROS_INFO("bianyi");
			par[se_i].pos1.x[ran2] = float(rand() % int(map.size()-400)+200);
			par[se_i].pos1.y[ran2] = float(rand() % int(map[1].size() -300) + 150);
			if (end_x >= start_x)
			{
				std::sort(par[se_i].pos1.x.begin() + 1, par[se_i].pos1.x.end() - 1);

			}
			else
			{
				std::sort(par[se_i].pos1.x.begin() + 1, par[se_i].pos1.x.end() - 1);
				std::reverse(par[se_i].pos1.x.begin() + 1, par[se_i].pos1.x.end() - 1);
			}
			if (end_y >= start_y)
			{
				std::sort(par[se_i].pos1.y.begin() + 1, par[se_i].pos1.y.end() - 1);
			}
			else
			{
				std::sort(par[se_i].pos1.y.begin() + 1, par[se_i].pos1.y.end() - 1);
				std::reverse(par[se_i].pos1.y.begin() + 1, par[se_i].pos1.y.end() - 1);
			}
		}
	}
}
void GA_P::posinit()
{
	for (int iter = 0; iter < N; iter++)
	{
		select();
		//std::cout << "  _____________" << std::endl;
		cross_connection();
		variation();
		
		for (int m = 0; m < M; m++)
		{
			partic.pos1.x = par[m].pos1.x;
			partic.pos1.y = par[m].pos1.y;
			index = 0;
			// inters=m;
			calFitness();
			if (par[m].fitness < par[m].best.fitness)
			{
				par[m].best.pos2 = par[m].pos1;
				par[m].best.fitness = par[m].fitness;
				par[m].best.path = par[m].path;
				if (par[m].best.fitness < glaob.fintess)
				{
					//glaob.path.clear();
					glaob.fintess = par[m].best.fitness;
					glaob.path = par[m].best.path;
					glaob.poss = par[m].best.pos2;

				}
			}
		}

	}
}
} ;// namespace GA_planner_j
