#!/bin/bash

source ./devel/setup.bash
roslaunch tianbot_mini simulation.launch &

echo "simulover"
sleep 10
echo "amcl"
source ./devel/setup.bash
roslaunch tianbot_mini amcl.launch &

sleep 10
echo "act"
source ./devel/setup.bash
rosrun duobiaoaction act

