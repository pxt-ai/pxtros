#include <ros/ros.h>
#include <ros/console.h>
#include <nav_msgs/Path.h>
#include <std_msgs/String.h>
#include <geometry_msgs/Quaternion.h>
#include <geometry_msgs/PoseStamped.h>
#include <tf/transform_broadcaster.h>
#include <tf/tf.h>
#include<iostream>
using namespace std;
#include<vector>
#include<fstream>
#include<string>
#include<sstream>
#include <iomanip>

#include <unistd.h>
#include <bits/stdc++.h>
#include <nav_msgs/Path.h>

int main(int argc,char *argv[])
{
    ros::init(argc,argv,"showpath");
    ros::NodeHandle nh;
    ros::Publisher path_pub = nh.advertise<nav_msgs::Path>("trajectory",10,true);
    ifstream infile("/home/hai/pxtl/pxt0005.txt");
     ros::Duration(110).sleep();
    int k = 0, l = 0;
    string line, value1, value;
     float cc ,bbb;
    ros::Time current_time,last_time;
    current_time = ros::Time::now();
    nav_msgs::Path path;
    path.header.stamp = current_time;
    path.header.frame_id = "tianbot_mini/map";
   
    
    while(getline(infile, line))
    {
        if(ros::ok())
        {
          size_t pos = line.find(":");
        if (pos != string::npos) {
            // 将冒号前后的字符串分别存储到pair中
            string key = line.substr(0, pos);
            string value = line.substr(pos + 1);
            //ROS_INFO("%s",key.c_str());
            if (key == "        x")
            {
                // ROS_INFO("1");
                if (value != " 0.0")
                {
                    //ROS_INFO("1");
                    l = l+1;
                    cc = stof(value);             
                }
            }
            if (key == "        y")
            {
                if (value != " 0.0")
                {
                    k = k+1;
                  bbb= stold(value);
           //      ROS_INFO("y%f",bbb);
             geometry_msgs::PoseStamped  su;
             su.header.frame_id="tianbot_mini/map";
            su.header.stamp=ros::Time::now();
                su.pose.position.x=cc;
                su.pose.position.y=bbb;
                su.pose.position.z=0.0;
                su.pose.orientation.x=0.0;
                su.pose.orientation.y=0.0;
                su.pose.orientation.z=0.0;
                su.pose.orientation.w=1.0;
                path.poses.push_back(su);
                path_pub.publish(path);
                  ROS_INFO("%f,%f",su.pose.position.x,su.pose.position.y);
                   //cout << key << " ";
                   //cout << value << endl;
                }
            }   
        }
      
        }
       
        
    }
    return 0;
}
