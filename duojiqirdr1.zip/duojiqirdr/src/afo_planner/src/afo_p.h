#ifndef AFO_P_H
#define AFO_P_H
#include<iostream>
#include<vector>
#include<algorithm>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 
#include <string>

/** include the libraries you need in your planner here */
#include <ros/ros.h>

#include <actionlib/client/simple_action_client.h>
#include <move_base_msgs/MoveBaseAction.h>

#include <geometry_msgs/Twist.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <move_base_msgs/MoveBaseGoal.h>
#include <move_base_msgs/MoveBaseActionGoal.h>

#include "sensor_msgs/LaserScan.h"
#include "sensor_msgs/PointCloud2.h"

#include <nav_msgs/Odometry.h>
#include <nav_msgs/OccupancyGrid.h>
#include <nav_msgs/Path.h>
#include <nav_msgs/GetPlan.h>

#include <tf/tf.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_listener.h>

#include <boost/foreach.hpp>
//#define forEach BOOST_FOREACH

/** for global path planner interface */
#include <costmap_2d/costmap_2d_ros.h>
#include <costmap_2d/costmap_2d.h>
#include <nav_core/base_global_planner.h>

#include <geometry_msgs/PoseStamped.h>
#include <angles/angles.h>

//#include <pcl_conversions/pcl_conversions.h>
//#include <base_local_planner/world_model.h>
//#include <base_local_planner/costmap_model.h>
namespace afo_pat
{

class fa_path :public nav_core::BaseGlobalPlanner
{
public:
	int fa_length;//一只包含的长度
	int numAgent;//初始种群数量
	int maxIteration;//最大迭代次数
	float FA_alpha;
	float FA_beta0;
	float FA_gama;
	float start_x, start_y, end_x, end_y;
    bool iinit;
        int width,height;
         ros::NodeHandle ROSNodeHandle;
         ros::Publisher _plan_pub;
         std::string _frame_id;
         float originX;
         float originY;
     float resolution;
       costmap_2d::Costmap2DROS* costmap_ros_;
            //double step_size_, min_dist_from_robot_;
    costmap_2d::Costmap2D* costmap_;
	struct point_xy
	{
		std::vector<float> x;
		std::vector<float> y;
	};
	struct gloal_best
	{
		float fitness;//适应度
		std::vector<std::vector<float>> path;//全局最佳路径
		point_xy x_y;
	};
	struct zi_best
	{
		float fitness;//适应度值
		std::vector<std::vector<float>> path;//局部最佳路径
		point_xy x_y1;
	};
	struct individuality
	{
		float fintess;
		int flag=0;
		std::vector<std::vector<float>> path;
		point_xy ever_xy;
		zi_best zi;



	};
	gloal_best gloal;
	individuality indvi;
	std::vector<individuality> par_i;
	std::vector<std::vector<int>> map;
	fa_path();
	~fa_path()
	{}
	void init_statAend(float s_x, float s_y, float e_x, float e_y);
	void population_init();
	void find_path_init();
	void FA_p();//萤火虫求解

fa_path (ros::NodeHandle &);
    fa_path(std::string name, costmap_2d::Costmap2DROS* costmap_ros);
      void getCorrdinate (float& x, float& y); 
	 void initialize(std::string name, costmap_2d::Costmap2DROS* costmap_ros);
    bool makePlan(const geometry_msgs::PoseStamped& start, const geometry_msgs::PoseStamped& goal,  std::vector<geometry_msgs::PoseStamped>& plan );
};
};
#endif