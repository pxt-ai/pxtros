#include"afo_p.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <string>
#include <cmath>
#include <time.h>
#include <random>
#include <vector>
#include <math.h>
#include<algorithm>
#include <numeric>

#include <pluginlib/class_list_macros.h>
PLUGINLIB_EXPORT_CLASS(afo_pat::fa_path, nav_core::BaseGlobalPlanner)
namespace afo_pat
{
    fa_path::fa_path()
    {

    }
    fa_path::fa_path (ros::NodeHandle &nh)
    {
ROSNodeHandle = nh;
    }
   fa_path::fa_path(std::string name, costmap_2d::Costmap2DROS* costmap_ros)
    {
 initialize(name,  costmap_ros);
    }
    void fa_path::initialize(std::string name, costmap_2d::Costmap2DROS* costmap_ros)
    {
 std::vector<int>ma;

            int cost;
            fa_length=3;//一只包含的长度
	numAgent=50;//初始种群数量
	maxIteration=50;//最大迭代次数
	FA_alpha=0.8;
	FA_beta0=0.9;
	FA_gama=1.2;
	gloal.fitness = 100000.0;
      iinit=false;
	
            if(!iinit)
            {
                 costmap_ros_ = costmap_ros;
            costmap_ = costmap_ros_->getCostmap();

            ros::NodeHandle private_nh("~/" + name);
            _plan_pub = private_nh.advertise<nav_msgs::Path>("global_plan", 1);
            _frame_id = costmap_ros->getGlobalFrameID();
             originX = costmap_->getOriginX();
            originY = costmap_->getOriginY();
			width = costmap_->getSizeInCellsX();
            height = costmap_->getSizeInCellsY();
            // x_max=float(width-200);
            // x_min=200.0;
            // y_max=float(height-150);
            //  y_min=150.0;
			ROS_INFO("width:%d,heeight:%d",width,height);
			
            for ( int ix= 0; ix < width; ix++)
            {
                for (int iy= 0; iy< height; iy++)
                {
                      cost = static_cast<int>(costmap_->getCost(ix, iy));
                      if(cost>0)
                      {
                          cost=1;
                      }
                  //  x.push_back(cost);
                  ma.push_back(cost);
				
                }
                map.push_back(ma);
                ma.clear();
                
            }	
			 resolution = costmap_->getResolution();
			 ROS_INFO("ACO planner initialized successfully");
          iinit = true;
    }
       else{
              ROS_WARN("This planner has already been initialized... doing nothing");
         }
            
    }
    bool fa_path::makePlan(const geometry_msgs::PoseStamped& start, const geometry_msgs::PoseStamped& goal,  std::vector<geometry_msgs::PoseStamped>& plan)
    {
		 std::pair<float, float> parii;
		
		 std::vector<std::pair<float, float>> controlPoints;
       fa_length=3;//一只包含的长度
	numAgent=50;//初始种群数量
	maxIteration=50;//最大迭代次数
	FA_alpha=0.8;
	FA_beta0=0.9;
	FA_gama=1.2;
	gloal.fitness = 100000.0;
	int id_h=0;
      controlPoints.clear();
 if (!iinit)
        {
            ROS_ERROR("The planner has not been initialized, please call initialize() to use the planner");
            return false;
        } 
        if (goal.header.frame_id != costmap_ros_->getGlobalFrameID())
        {
            ROS_ERROR("This planner as configured will only accept goals in the %s frame, but a goal was sent in the %s frame.",
                costmap_ros_->getGlobalFrameID().c_str(), goal.header.frame_id.c_str());
            return false;
        }  
         tf::Stamped<tf::Pose> goal_tf;
    tf::Stamped<tf::Pose> start_tf;
    poseStampedMsgToTF(goal, goal_tf);
    poseStampedMsgToTF(start, start_tf);
     float startX = start.pose.position.x;
    float startY = start.pose.position.y;
//ROS_INFO("stary=%.2f",startY);
        float goalX = goal.pose.position.x;
        float goalY = goal.pose.position.y;
        //ROS_INFO("goaly=%.2f",goalY);
        getCorrdinate(startX, startY);   //获取起点在世界坐标系下的坐标
        getCorrdinate(goalX, goalY);  
		ROS_INFO("s=%.2f,%.2f,g=%.2f,%.2f",startX,startY,goalX,goalY);
		//int kx=abs(int (startX/resolution/100)-int((goalX/resolution)/100));
		
controlPoints.clear();
x_.push_back(goalX);
y_.push_back(goalY);
if(x_.size()>=2)
{
	if(goalX==x_[x_.size()-2]&&goalY==y_[y_.size()-2])
	{
id_h=1;
	}
	x_.clear();
	y_.clear();
}
        if(sqrt(pow(startX-goalX,2)+pow(startY-goalY,2))>0.3&&id_h==1)
       {
           plan.clear();
	 gloal.diann1.clear();
	 gloal.path.clear();
	 gloal.x_y.x.clear();
	 gloal.x_y.y.clear();
	 gloal.fitness=100000.0;
	indvi.ever_xy.x.clear();
	indvi.ever_xy.y.clear();
	indvi.path.clear();
	indvi.fintess=100000.0;
	indvi.zi.fitness=100000.0;
	indvi.zi.path.clear();
	indvi.zi.x_y1.x.clear();
	indvi.zi.x_y1.y.clear();

par_i.resize(numAgent);
  indvi.ever_xy.x.resize(fa_length);
	indvi.ever_xy.y.resize(fa_length);		   
           init_statAend(startX, startY,goalX, goalY);
           FA_p();
       
    if(gloal.path.size()!=0)
    {
		//ROS_INFO("ggs:%d",gloal.diann1[0].size());
     for(int ss=0;ss<gloal.diann1[0].size();ss++)
{
parii.first=gloal.diann1[0][ss];
parii.second=gloal.diann1[1][ss];
//ROS_INFO("%.2f,   ,%.2f ",parii.first,parii.second);
controlPoints.push_back(parii);

}

	  int numSmoothPoints=int(gloal.path[0].size()/1.7);
	  if(numSmoothPoints<20)
	  {
	  numSmoothPoints=15;
		  
	  }
        std::vector<std::pair<float, float>> smoothPoints = GenerateSmoothPoints(controlPoints, numSmoothPoints);
      

parii.first=gloal.diann1[0][gloal.diann1[0].size()-1];
parii.second=gloal.diann1[1][gloal.diann1[0].size()-1];
smoothPoints.push_back(parii);	
        for (int i = 0; i<numSmoothPoints+1; i++)
	{
					float x = 0.0;
                    float y = 0.0;

                    

                    geometry_msgs::PoseStamped pose = goal;

                    pose.pose.position.x = smoothPoints[i].first*  resolution +originX;
                    pose.pose.position.y =  smoothPoints[i].second*resolution+originY;
                    pose.pose.position.z = 0.0;

                    pose.pose.orientation.x = 0.0;
                    pose.pose.orientation.y = 0.0;
                    pose.pose.orientation.z = 0.0;
                    pose.pose.orientation.w = 1.0;

                    plan.push_back(pose);

		//std::cout << "("<<my_A.node[resut.path1[i]][0] << ","<<my_A.node[resut.path1[i]][1]<<")"<<std::endl;
	}
         nav_msgs::Path path;
	     path.poses.resize(plan.size());  
          if (plan.empty())
                {
                    //still set a valid frame so visualization won't hit transform issues
                    path.header.frame_id = _frame_id;
                    path.header.stamp = ros::Time::now();
                }
                else
                {
                    path.header.frame_id = plan[0].header.frame_id;
                    path.header.stamp = plan[0].header.stamp;
                }       
                     for (int i = 0; i < plan.size(); i++)
                {
                    path.poses[i] = plan[i];
                }
				    for (int i = 0; i < plan.size(); i++)
                {
                    path.poses[i] = plan[i];
                }
     // ROS_INFO("7");
                _plan_pub.publish(path);
			   ROS_INFO("The planner find a path......, ");
			  
gloal.fitness=100000.0;
	par_i.clear();
	//path.poses.clear();
    return true;

    }
    else{
        ROS_WARN("The planner failed to find a path, choose other goal position");
              gloal.fitness=100000.0;
	par_i.clear();
                return false;
    }

       } 
       else
       {
           ROS_WARN("Not valid start or goal");
             


	gloal.fitness=100000.0;
	par_i.clear();
            return false;
       }

    }
void fa_path::getCorrdinate (float& x, float& y)
     {
         x = x - originX;
        y = y - originY;
     }
	  float fa_path::BSplineBasis(int i, int k, float t, const std::vector<float>& knots)
	  {
 if (k == 0) {
        return (knots[i] <= t && t < knots[i + 1]) ? 1.0 : 0.0;
    }
    float h1 = (knots[i + k] - knots[i]);
    float h2 = (knots[i + k + 1] - knots[i + 1]);
    if (h1 == 0)
        h1 = 1;
    if (h2==0)
    {
        h2 = 1;
    }
    float alpha = (t - knots[i]) /h1;
   // std::cout << alpha<<" ";
    float beta = (knots[i + k+1] - t) / h2;
   // float ht= alpha * BSplineBasis(i, k - 1, t, knots) + beta * BSplineBasis(i + 1, k - 1, t, knots);
   // std::cout << ht<<" ";
    return alpha * BSplineBasis(i, k - 1, t, knots) + beta * BSplineBasis(i + 1, k - 1, t, knots);
	  }
std::pair<float, float> fa_path::CubicBSplinePoint(float t, const std::vector<std::pair<float, float>>& controlPoints, const std::vector<float>& knots) 
{
 float x = 0.0, y = 0.0;
    int n = controlPoints.size()-1 ;
    for (int i = 0; i <=n; i++ ) {
        x += controlPoints[i].first * BSplineBasis(i, 3, t, knots);
       // std::cout << BSplineBasis(i, 3, t, knots) << " ";
        y += controlPoints[i].second * BSplineBasis(i, 3, t, knots);
    }
    return { x, y };
}
std::vector<std::pair<float, float>> fa_path::GenerateSmoothPoints(const std::vector<std::pair<float, float>>& controlPoints, int numPoints)
{
std::vector<std::pair<float, float>> smoothPoints;
    std::vector<float> knots;
    
    // 创建knot向量  
    int n = controlPoints.size();
    int p = n-3;
    int flag = 1;
    knots.resize(n + 4,0);
    if (p == 1)
    {
        for (int k = 4; k < n + 4; k++)
        {
            knots[k] = 1.0;
        }
   }
    else
    {
        while (flag!=p)
        {
            knots[3 + flag] = knots[2 + flag] + 1.0 / p;
           // std::cout <<" kn= "<< knots[3 + flag] << " ";
            flag++;
        }
        for (int l = n; l < n+3+1; l++)
        {
            knots[l] = 1.0;
        }
       
    }
    
   

    // 计算平滑曲线上的点  
    float t = 0;
    //float t1 = float(n + 2) / (n + 4 +1);
    float step = 1.0/ float(numPoints);
    //while(t<(1-0.05))
    for (int i = 0; i < numPoints;i++) 
    {
        smoothPoints.push_back(CubicBSplinePoint(t, controlPoints, knots));
        t += step;
    }

    return smoothPoints;
}

     void fa_path::init_statAend(float s_x,float s_y,float e_x,float e_y)//对目标点和初始点初始化
{

	this->start_x = s_x/resolution;
	this->start_y = s_y/resolution;
	this->end_x = e_x/resolution;
	this->end_y = e_y/resolution;
	population_init();
}
void fa_path::population_init()
{
	ROS_INFO("1");
	int kl=0;
	std::vector<float> x__,y__;
	float rand1 = 0.0, rand2 = 0.0;
	
	//par_i.clear();
	for (int i = 0; i < numAgent; i++)
	{
		
		for (int l = 0; l < fa_length; l++)
		{
			if (i < 10)
		{
			if (int(std::abs(start_x- end_x)) != 0)
			{
				rand1 = float(rand() % int(abs(start_x- end_x) ) + std::min(start_x,end_x) );
				//cout << rand1<<endl;
			}
			else
			{
				rand1 = start_x;
			}
			if (abs(end_y - start_y) != 0)
			{
				rand2 = float(rand() % int(abs(start_y- end_y) ) +std:: min(end_y,start_y) );
				//cout << rand2 << endl;
			}
			else
			{
				rand2 = end_y;
			}
		}
		
		else if(i>numAgent-20)
		{
			int k = 0;
			int k1 = 0;
			if (rand() % 100 / 100.0 < 0.5)
			{
				k = i;
			}
			else
			{
				k = -i;
			}
			if (rand() % 100 / 100.0 < 0.5)
			{
				k1 = i;
			}
			else
			{
				k1 = -i;
			}

			if (int(abs(start_x- end_x)) != 0)
			{
				rand1 = float(rand() % int(abs(start_x- end_x) + 1.3* k) + std::min(start_x, end_y) + 2 * k);
				//cout << rand1 << endl;
			}
			
			else
			{
				rand1 = end_x;
			}
			if (abs(end_y - start_y) != 0)
			{
				rand2 = float(rand() % int(abs(end_y- start_y) + 1.3 * k1) + std::min(end_y, start_y) + 2* k1);
				//cout << rand2 << endl;
			}
			else
			{
				rand2 = 0;
			}
		}
		else
		{
			int tandd=rand()%25;
			
			if (int(std::abs(start_x- end_x)) != 0)
			{
				rand1 = float(rand() % int(abs(start_x- end_x) ) + std::min(start_x,end_x) );
				//cout << rand1<<endl;
			}
			else
			{
				rand1 = start_x;
			}
			if (abs(end_y - start_y) != 0)
			{
				rand2 = float(rand() % int(abs(start_y- end_y) ) +std:: min(end_y,start_y) );
				//cout << rand2 << endl;
			}
			else
			{
				rand2 = end_y;
			}
				//cout << rand1<<endl;
				float kk1=0.0,kk2=0.0;
			for(int ttt=0;ttt<tandd;ttt++)
			{

				if(rand()%100/100.0<0.5)
				{
					 kk1=5.5;
				}
				else{
					kk1=-5.5;
				}
					if(rand()%100/100.0<0.5)
				{
					 kk2=5.5;
				}
				else{
					kk2=-5.5;
				}
				
			
     
				rand1=rand1+kk1;
				//cout << rand1<<endl;
			
		
			
				rand2 = rand2+kk2;
				//cout << rand2 << endl;
		
			
			}
		}
		if(rand1>=float(map.size())||rand1<0.0)
		{
			if (int(std::abs(start_x- end_x)) != 0)
			{
				rand1 = float(rand() % int(abs(start_x- end_x) ) + std::min(start_x,end_x) );
				//cout << rand1<<endl;
			}
			else
			{
				rand1 = start_x;
			}
		}
		if(rand2>=float(map[0].size())||rand2<0.0)
		{
			
				if (abs(end_y - start_y) != 0.0)
			{
				rand2 = float(rand() % int(abs(start_y- end_y) ) +std:: min(end_y,start_y) );
				//cout << rand2 << endl;
			}
			else
			{
				rand2 = end_y;
			}
		}
		ROS_INFO("%d   ,%d,rand1  %.2f,  rand2   %.2f ",i,l,rand1,rand2);
		
while(1)
{
	if(map[int(rand1)][int(rand2)]==0)
	{
	//	ROS_INFO("13");
		break;
	}
if(rand()%100/100.0<0.5)
         {  
			// ROS_INFO("55");
			 	if (int(std::abs(start_x- end_x)) != 0)
			{
				rand1 = float(rand() % int(abs(start_x- end_x) ) + std::min(start_x,end_x) );
				//cout << rand1<<endl;
			}
			else
			{
				rand1 = start_x;
			}
			if (abs(end_y - start_y) != 0)
			{
				rand2 = float(rand() % int(abs(start_y- end_y) ) +std:: min(end_y,start_y) );
				//cout << rand2 << endl;
			}
			else
			{
				rand2 = end_y;
			}
			// ROS_INFO("556");
		 }
		 else{
			 int k = 0;
			int k1 = 0;
			if (rand() % 100 / 100.0 < 0.5)
			{
				k = i;
			}
			else
			{
				k = -i;
			}
			if (rand() % 100 / 100.0 < 0.5)
			{
				k1 = i;
			}
			else
			{
				k1 = -i;
			}

			if (int(abs(start_x- end_x)) != 0)
			{
				rand1 = float(rand() % int(abs(start_x- end_x) + (rand()%3)* k) + std::min(start_x, end_y) + (rand()%100/30.0)* k);
				//cout << rand1 << endl;
			}
			
			else
			{
				rand1 = end_x;
			}
			if (abs(end_y - start_y) != 0)
			{
				rand2 = float(rand() % int(abs(end_y- start_y) + (rand()%3 )* k1) + std::min(end_y, start_y) + (rand()%100/30.0)* k1);
				//cout << rand2 << endl;
			}
			else
			{
				rand2 = end_y;
			}
		 }
		 	if(rand1>=float(map.size())||rand1<0.0)
		{
			if (int(std::abs(start_x- end_x)) != 0)
			{
				rand1 = float(rand() % int(abs(start_x- end_x) ) + std::min(start_x,end_x) );
				//cout << rand1<<endl;
			}
			else
			{
				rand1 = start_x;
			}
		}
		 //ROS_INFO("7777");
		if(rand2>=float(map[0].size())||rand2<0)
		{
			
				if (abs(end_y - start_y) != 0)
			{
				rand2 = float(rand() % int(abs(start_y- end_y) ) +std:: min(end_y,start_y) );
				//cout << rand2 << endl;
			}
			else
			{
				rand2 = end_y;
			}
		}
		//ROS_INFO("4251,rand1%.2f,  rand2%.2f ",rand1,rand2);
		 //ROS_INFO("5567");
}
	        //ROS_INFO("5,%d",l);
			x__.push_back(rand1);
			y__.push_back(rand2);
      // 	ROS_INFO("42511,rand1%.2f,  rand2%.2f ",rand1,rand2);
		//	ROS_INFO("6");
		}     
		indvi.ever_xy.x=x__;
		indvi.ever_xy.y =y__;
		x__.clear();
		y__.clear();

		//ROS_INFO("4,%d",i);
		par_i[i]=indvi;
			

		}
	//ROS_INFO("4");
	find_path_init();
	//ROS_INFO("13");
}
void fa_path::find_path_init()
{
	ROS_INFO("2");
	float x=0.0, y=0.0, sum=0.0;
	std::vector<float>x_seq,y_seq;//将生成的优化点和开始结束点拼接
	std::vector<float> X_seq, Y_seq;//生成路径坐标点存放位置
	for (int i_x = 0; i_x < par_i.size(); i_x++)
	{
		x_seq.push_back(start_x);
		y_seq.push_back(start_y);
		for (int point_num = 0; point_num < fa_length; point_num++)
		{
			x_seq.push_back(par_i[i_x].ever_xy.x[point_num]);
			y_seq.push_back(par_i[i_x].ever_xy.y[point_num]);
		}
		x_seq.push_back(end_x);
		y_seq.push_back(end_y);


		for (int i = 1; i < x_seq.size(); i++)
		{

			if (abs(x_seq[i] - x_seq[i - 1]) >= abs(y_seq[i] - y_seq[i - 1]))
			{

				for (int x_z = int(x_seq[i - 1]); x_z<int(x_seq[i]); x_z++)
				{
					x = float(x_z);
					//std::cout << x << " ";
					if (x_seq[i] - x_seq[i - 1] == 0)
					{
						y = y_seq[i];
					}
					else
					{
						y = y_seq[i - 1] + (x - x_seq[i - 1]) * (y_seq[i] - y_seq[i - 1]) / (x_seq[i] - x_seq[i - 1]);
						if(y>=float(map.size()))
						{
							y =float( map.size() - 1);
						}
					}
					X_seq.push_back(x);
					Y_seq.push_back(y);
				}

			}
			else
			{
				for (int y_z = int(y_seq[i - 1]); y_z<int(y_seq[i]); y_z++)
				{
					y = float(y_z);
					if (y_seq[i] - y_seq[i - 1] == 0)
					{
						x = x_seq[i];
					}
					else
					{
						x = x_seq[i - 1] + (y - y_seq[i - 1]) * (x_seq[i] - x_seq[i - 1]) / (y_seq[i] - y_seq[i - 1]);
						//std::cout << x<<" ";
					}
					X_seq.push_back(x);
					Y_seq.push_back(y);
				}

			}
		}
		X_seq.push_back(end_x);
		Y_seq.push_back(end_y);
			//par_i[i_x].ever_xy.x = x_seq;
			//par_i[i_x].ever_xy.y = y_seq;
			par_i[i_x].path.push_back(X_seq);
			par_i[i_x].path.push_back(Y_seq);
			//std::cout <<"k: "<< par_i[i_x].path[0].size() << " "<<std::endl;

			for (int k = 1; k < X_seq.size(); k++)
			{
				//std::cout << "(" << int(X_seq[k]) << "," << int(Y_seq[k]) << ")" << std::endl;
				if (map[int(X_seq[k])][int(Y_seq[k])] == 1)//越界了
				{
					par_i[i_x].flag = 1;
				}
				sum = sum + sqrt(pow(X_seq[k] - X_seq[k - 1], 2) + pow(Y_seq[k] - Y_seq[k - 1], 2));
			}
			if (par_i[i_x].flag == 1)
			{
				par_i[i_x].fintess = sum * 100;
			}
			else
			{
				par_i[i_x].fintess = sum;
			}
			
			par_i[i_x].zi.fitness = par_i[i_x].fintess;
			par_i[i_x].zi.path = par_i[i_x].path;
			par_i[i_x].zi.x_y1 = par_i[i_x].ever_xy;
			//std::cout << ":" << par_i[i_x].fintess << " ";
			if (par_i[i_x].fintess < gloal.fitness)
			{
				gloal.fitness = par_i[i_x].fintess;
				gloal.path.clear();
				gloal.path.push_back(X_seq);
				gloal.path.push_back(Y_seq);
				gloal.diann1.clear();
				gloal.diann1.push_back(x_seq);
				gloal.diann1.push_back(y_seq);
				//std::cout << "1: " << gloal.fitness << " ";
				ROS_INFO("fitness=%.2f",gloal.fitness);
				gloal.x_y = par_i[i_x].ever_xy;
				//std::cout << ":" << gloal.path[0].size() << " ";
			}
			x_seq.clear(); y_seq.clear();
			X_seq.clear(); Y_seq.clear();
		
	}
	//ROS_INFO("8");
}
void fa_path::FA_p()
{/*
			   I(i,j)=y(i)*exp(-option.FA_gama*r(i,j)^2);
				beta(i,j)=option.FA_beta0*exp(-option.FA_gama*r(i,j)^2);
 */
ROS_INFO("3--------------------------------------------------------------------------------------------------------------------------------");
	int min_indx = 0, max_indx = 0;
	std::vector<std::vector<float>>I, beta;
	std::vector<float> i1, be;
	std::vector<std::vector<float>> dist;//萤火虫距离
	std::vector<float> dis1;
	float kk1=0.0,kk2=0.0,kk3=0.0;
	for (int iter = 0; iter < maxIteration; iter++)
	{
		
		float sum = 0.0, sum1 = 0.0, sum3 = 0.0, min_f = 1000000.0, max_f = 0.0;
		for (int i = 0; i < par_i.size(); i++)
		{
			for (int k = 0; k < par_i.size(); k++)
			{
				for (int l = 0; l < par_i[i].ever_xy.x.size(); l++)
				{
					sum = sum + pow(par_i[i].ever_xy.x[l] - par_i[k].ever_xy.x[l], 2);
					sum1 = sum1 + pow(par_i[i].ever_xy.y[l] - par_i[k].ever_xy.y[l], 2);

				}
				sum = sqrt(sum + sum1);
				//std::cout << sum<<" ";
				sum3 = par_i[i].fintess * pow(2.17, -FA_gama * pow(sum, 2));
				i1.push_back(sum3);
				sum3 = FA_beta0 * pow(2.17, -FA_gama * pow(sum, 2));
				be.push_back(sum3);
				dis1.push_back(sum);
			}
			I.push_back(i1);
			i1.clear();
			beta.push_back(be);
			be.clear();
			dist.push_back(dis1);
			dis1.clear();
			if (par_i[i].fintess > max_f)
			{

				max_f = par_i[i].fintess;
				max_indx = i;
			}
			if (par_i[i].fintess < min_f)
			{

				min_f = par_i[i].fintess;
				min_indx = i;
			}
		}
		for (int i = 0; i < par_i.size(); i++)
		{
			if (gloal.fitness < 100 * sqrt(pow(start_x - end_x, 2) + pow(start_y - end_y, 2)))
			{
				if (rand() % 100 / 100.0 > 0.5)
				{
					// x(i,:)=x(i,:)+beta(i,no)*(x(no,:)-x(i,:))+option.FA_alpha*(rand(size(x(1,:)))-0.5);
					for (int k = 0; k < par_i[i].ever_xy.x.size(); k++)
					{
						if(float(rand()%100/100.0)<0.5)
						{
							kk1=1.0;
						}
						else
						{
							kk1=-1.0;
						}
						if(float(rand()%100/100.0)<0.5)
						{
							kk2=1.0;
						}
						else
						{
							kk2=-1.0;
						}

						par_i[i].ever_xy.x[k] = par_i[i].ever_xy.x[k] + beta[i][min_indx] * (par_i[min_indx].ever_xy.x[k] - par_i[i].ever_xy.x[k]) + FA_alpha * ((rand() % par_i[i].ever_xy.x.size()) - 0.5)+kk1;
						if (par_i[i].ever_xy.x[k] >= map.size())//防止越界
						{
							par_i[i].ever_xy.x[k] = float(map.size()-1);
						}
						if (par_i[i].ever_xy.x[k] < 0)
						{
							par_i[i].ever_xy.x[k] = 0;
						}
						par_i[i].ever_xy.y[k] = par_i[i].ever_xy.y[k] + beta[i][min_indx] * (par_i[min_indx].ever_xy.y[k] - par_i[i].ever_xy.y[k]) + FA_alpha * ((rand() % par_i[i].ever_xy.y.size()) - 0.5)+kk2;
						if (par_i[i].ever_xy.y[k] >=map[0].size())//防止越界
						{
							par_i[i].ever_xy.y[k] = float(map[0].size()-1);
						}
						if (par_i[i].ever_xy.y[k] < 0)
						{
							par_i[i].ever_xy.y[k] = 0;
						}
					}
				}
				else
				{

					for (int k = 0; k < par_i[i].ever_xy.x.size(); k++)
					{
							if(float(rand()%100/100.0)<0.5)
						{
							kk1=1.0;
						}
						else
						{
							kk1=-1.0;
						}
						if(float(rand()%100/100.0)<0.5)
						{
							kk2=1.0;
						}
						else
						{
							kk2=-1.0;
						}
						par_i[i].ever_xy.x[k] = par_i[i].ever_xy.x[k] + beta[i][rand() % beta[i].size()] * (par_i[rand() % beta[i].size()].ever_xy.x[k] - par_i[i].ever_xy.x[k]) + FA_alpha * ((rand() % par_i[i].ever_xy.x.size()) - 0.5)+kk1;
						//std::cout << par_i[i].ever_xy.x[k]<<" ";
						if (par_i[i].ever_xy.x[k] >= map.size())//防止越界
						{
							par_i[i].ever_xy.x[k] = float(map.size()-1);
						}
						if (par_i[i].ever_xy.x[k] < 0)
						{
							par_i[i].ever_xy.x[k] = 0;
						}
						par_i[i].ever_xy.y[k] = par_i[i].ever_xy.y[k] + beta[i][rand() % beta[i].size()] * (par_i[rand() % beta[i].size()].ever_xy.y[k] - par_i[i].ever_xy.y[k]) + FA_alpha * ((rand() % par_i[i].ever_xy.y.size()) - 0.5)+kk2;
						if (par_i[i].ever_xy.y[k] >= map[0].size())//防止越界
						{
							par_i[i].ever_xy.y[k] = float(map[0].size()-1);
						}
						if (par_i[i].ever_xy.y[k] < 0)
						{
							par_i[i].ever_xy.y[k] = 0;
						}
					}
				}
			}
			else
			{
				if (rand() % 100 / 100.0 > 0.5)
				{
					// x(i,:)=x(i,:)+beta(i,no)*(x(no,:)-x(i,:))+option.FA_alpha*(rand(size(x(1,:)))-0.5);
					for (int k = 0; k < par_i[i].ever_xy.x.size(); k++)
					{
							if(float(rand()%100/100.0)<0.5)
						{
							kk1=1.0;
						}
						else
						{
							kk1=-1.0;
						}
						if(float(rand()%100/100.0)<0.5)
						{
							kk2=1.0;
						}
						else
						{
							kk2=-1.0;
						}
						par_i[i].ever_xy.x[k] = par_i[i].ever_xy.x[k] + beta[i][max_indx] * (par_i[max_indx].ever_xy.x[k] - par_i[i].ever_xy.x[k]) + FA_alpha * ((rand() % par_i[i].ever_xy.x.size()) - 0.5)+kk1;
					//	std::cout << par_i[i].ever_xy.x[k] << " ";
						if (par_i[i].ever_xy.x[k] >= map.size())//防止越界
						{
							par_i[i].ever_xy.x[k] = float(map.size()-1);
						}
						if (par_i[i].ever_xy.x[k] < 0)
						{
							par_i[i].ever_xy.x[k] = 0;
						}

						par_i[i].ever_xy.y[k] = par_i[i].ever_xy.y[k] + beta[i][max_indx] * (par_i[max_indx].ever_xy.y[k] - par_i[i].ever_xy.y[k]) + FA_alpha * ((rand() % par_i[i].ever_xy.y.size()) - 0.5)+kk2;
						if (par_i[i].ever_xy.y[k] >= map[0].size())//防止越界
						{
							par_i[i].ever_xy.y[k] = float(map[0].size()-1);
						}
						if (par_i[i].ever_xy.y[k] < 0)
						{
							par_i[i].ever_xy.y[k] = 0;
						}
					}
				}
				else
				{
					for (int k = 0; k < par_i[i].ever_xy.x.size(); k++)
					{
							if(float(rand()%100/100.0)<0.5)
						{
							kk1=1.0;
						}
						else
						{
							kk1=-1.0;
						}
						if(float(rand()%100/100.0)<0.5)
						{
							kk2=1.0;
						}
						else
						{
							kk2=-1.0;
						}
						par_i[i].ever_xy.x[k] = par_i[i].ever_xy.x[k] + beta[i][rand() % beta[i].size()] * (par_i[rand() % beta[i].size()].ever_xy.x[k] - par_i[i].ever_xy.x[k]) + FA_alpha * ((rand() % par_i[i].ever_xy.x.size()) - 0.5)+kk1;
						if (par_i[i].ever_xy.x[k] >= map.size())//防止越界
						{
							par_i[i].ever_xy.x[k] = float(map.size()-1);
						}
						if (par_i[i].ever_xy.x[k] < 0)
						{
							par_i[i].ever_xy.x[k] = 0;
						}
						par_i[i].ever_xy.y[k] = par_i[i].ever_xy.y[k] + beta[i][rand() % beta[i].size()] * (par_i[rand() % beta[i].size()].ever_xy.y[k] - par_i[i].ever_xy.y[k]) + FA_alpha * ((rand() % par_i[i].ever_xy.y.size()) - 0.5)+kk2;
						if (par_i[i].ever_xy.y[k] >= map[0].size())//防止越界
						{
							par_i[i].ever_xy.y[k] = float(map[0].size()-1);
						}
						if (par_i[i].ever_xy.y[k] < 0)
						{
							par_i[i].ever_xy.y[k] = 0;
						}
					}
				}
			}
		}
		//std::cout << iter<<std::endl;
		//population_init();
		find_path_init();

		I.clear();  beta.clear();
	}
	//ROS_INFO("10");
}
};