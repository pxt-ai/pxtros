#ifndef PSO_D_H
#define PSO_D_H
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 
#include <string>

/** include the libraries you need in your planner here */
#include <ros/ros.h>

#include <actionlib/client/simple_action_client.h>
#include <move_base_msgs/MoveBaseAction.h>

#include <geometry_msgs/Twist.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <move_base_msgs/MoveBaseGoal.h>
#include <move_base_msgs/MoveBaseActionGoal.h>

#include "sensor_msgs/LaserScan.h"
#include "sensor_msgs/PointCloud2.h"

#include <nav_msgs/Odometry.h>
#include <nav_msgs/OccupancyGrid.h>
#include <nav_msgs/Path.h>
#include <nav_msgs/GetPlan.h>

#include <tf/tf.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_listener.h>

#include <boost/foreach.hpp>
//#define forEach BOOST_FOREACH

/** for global path planner interface */
#include <costmap_2d/costmap_2d_ros.h>
#include <costmap_2d/costmap_2d.h>
#include <nav_core/base_global_planner.h>

#include <geometry_msgs/PoseStamped.h>
#include <angles/angles.h>

//#include <pcl_conversions/pcl_conversions.h>
//#include <base_local_planner/world_model.h>
//#include <base_local_planner/costmap_model.h>
#include<algorithm>

#include <set>

#include<vector>
#include<algorithm>
namespace p_planner
{
class pso:public nav_core::BaseGlobalPlanner
{
public:
	pso();
	~pso()
	{

	}

    pso(ros::NodeHandle &);
    pso(std::string name, costmap_2d::Costmap2DROS* costmap_ros);
    bool iinit;
    int width,height;
      ros::NodeHandle ROSNodeHandle;
    ros::Publisher _plan_pub;
    std::string _frame_id;
    float originX;
    float originY;
     float resolution;
      costmap_2d::Costmap2DROS* costmap_ros_;
            //double step_size_, min_dist_from_robot_;
    costmap_2d::Costmap2D* costmap_;
    void initialize(std::string name, costmap_2d::Costmap2DROS* costmap_ros);
    bool makePlan(const geometry_msgs::PoseStamped& start, const geometry_msgs::PoseStamped& goal,  std::vector<geometry_msgs::PoseStamped>& plan );
	int N;//迭代次数
	int M; //粒子数量
	float w;//惯性权重
	float c1;
	float c2;
	float globfit;
	int pointNum;
	float alpha;
	int inters = 0;
	float start_x, start_y, end_x, end_y;
	std::vector<std::vector<int>> map;
	struct v {
		std::vector<float> x;
		std::vector<float> y;
	};
	struct pos
	{
		std::vector<float> x;
		std::vector<float> y;
	};
	struct glob {
		std::vector<std::vector<float>>path;
		float fintess;
		pos poss;
	};
	struct Best
	{
		pos pos2;
		float fitness;
		std::vector<std::vector<float>> path;

	};

	struct particles
	{
		pos pos1;
		v v1;
		int flag = 0;
		float fitness;
		std::vector<std::vector<float>> path;
		Best best;
		
	};
	
	particles partic;
	std::vector<particles>par;
	glob glaob;
	int index=0;
	void posinit();
	void calFitness();
	void init(float s_x, float s_y, float e_x, float e_y);
     void getCorrdinate (float& x, float& y); 
};
};
#endif // !PSO_PLANNER_H
