##一.打开方式
##将功能包放置工作空间下右键打开终端编译
## catkin_make

##编译成功后进入工作空间右键输入指令source
## source devel/setup.bash

##打开Gazebo仿真环境
## roslaunch *** urdf_gazebo testworld.launch



##二.修改方式
##修改之前需要去官网下载gazebo_models,打开终端输入指令
## git clone https://github.com/osrf/gazebo_models

##打开仿真环境后，点击左上角inset，点击Add Path找到下载的gazebo_models导入模型，可任意选择模型添加

##修改完成之后点击左上角File，点击save world as,选择保存的路径，建议放在worlds目录下

##关闭gazebo，找到并打开urdf_gazebo/launch下的testworld.launch，
##将<arg name="world_name" value="$(find urdf_gazebo)/worlds/testworld.world" />中的testworld.launch改为当时保存的环境名称
